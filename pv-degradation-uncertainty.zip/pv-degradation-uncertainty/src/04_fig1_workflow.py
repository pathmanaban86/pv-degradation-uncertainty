"""Builds Fig. 1 (test procedure and analysis chain) as an editable draw.io file and a matching PDF/PNG preview.

Usage: python src/04_fig1_workflow.py [output_dir]
"""
# Builds Fig. 1 (test procedure and analysis chain) as an editable draw.io file and a matching preview.
import html, os, sys, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

BLUE, AQUA, ORANGE, INK, GREY = "#2a78d6", "#1baf7a", "#eb6834", "#222222", "#6b6b6b"
FILL = {BLUE: "#dbe8f9", AQUA: "#d6f2e6", ORANGE: "#fbe3d9"}
W, H = 230, 84
# Output folder: first argument, default ../figures relative to this script
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(OUT, exist_ok=True)
# id, x, y, colour, draw.io html label, matplotlib label
B = [
 ("ref", 150, 60, BLUE, "<b>Reference I–V</b><br>before installation<br><i>t</i> = 0", "Reference I–V\nbefore installation\n$t$ = 0"),
 ("exp", 410, 60, BLUE, "<b>Outdoor exposure</b><br>hot, dry site<br><i>t</i> = 0–5.2 yr", "Outdoor exposure\nhot, dry site\n$t$ = 0–5.2 yr"),
 ("iv", 670, 60, BLUE, "<b>Indoor flash I–V</b><br>one simulator, 1051 curves<br><i>T</i> = 25.0 ± 0.2 °C", "Indoor flash I–V\none simulator, 1051 curves\n$T$ = 25.0 ± 0.2 °C"),
 ("el", 930, 60, BLUE, "<b>EL imaging</b><br><i>H</i>: 80% <i>I</i><sub>sc</sub>, <i>L</i>: 20% <i>I</i><sub>sc</sub><br>8-bit, display-scaled", "EL imaging\n$H$: 80% $I_\\mathrm{sc}$, $L$: 20% $I_\\mathrm{sc}$\n8-bit, display-scaled"),
 ("ext", 150, 290, AQUA, "<b>Parameter extraction</b><br><i>I</i><sub>sc</sub>, <i>V</i><sub>oc</sub>, <i>P</i><sub>mp</sub>, <i>R</i><sub>s</sub><br>Eq. (2)", "Parameter extraction\n$I_\\mathrm{sc}$, $V_\\mathrm{oc}$, $P_\\mathrm{mp}$, $R_\\mathrm{s}$\nEq. (2)"),
 ("pair", 410, 290, AQUA, "<b>Pairing with reference</b><br>relative change <i>y</i><sub><i>ij</i></sub><br>Eqs. (4)–(5)", "Pairing with reference\nrelative change $y_{ij}$\nEqs. (4)–(5)"),
 ("corr", 670, 290, AQUA, "<b>Corrections</b><br><i>c</i><sup>−<i>β</i></sup>, <i>β</i> = 0.195<br>contact bound <i>f</i>", "Corrections\n$c^{-\\beta}$, $\\beta$ = 0.195\ncontact bound $f$"),
 ("mc", 930, 290, AQUA, "<b>Monte Carlo propagation</b><br><i>N</i> = 4000, module bootstrap<br>scenarios A, B, C", "Monte Carlo propagation\n$N$ = 4000, module bootstrap\nscenarios A, B, C"),
 ("out", 1190, 290, AQUA, "<b>Results</b><br><i>R</i><sub>d</sub>, 95% interval, <i>U</i> (<i>k</i> = 2)<br>variance shares", "Results\n$R_\\mathrm{d}$, 95% interval, $U$ ($k$ = 2)\nvariance shares"),
 ("seg", 410, 480, ORANGE, "<b>Cell segmentation</b><br>visit matching<br><i>ρ</i> ≥ 0.6", "Cell segmentation\nvisit matching\n$\\rho$ ≥ 0.6"),
 ("map", 670, 480, ORANGE, "<b>Ratio map</b><br><i>r</i>(<i>x</i>,<i>y</i>), Eq. (3)<br>metric <i>s</i><sub>r</sub>", "Ratio map\n$r(x,y)$, Eq. (3)\nmetric $s_\\mathrm{r}$"),
 ("res", 930, 480, ORANGE, "<b>Resolution</b><br>Δ<i>s</i><sub>r</sub>, <i>σ</i><sub>Δ</sub><br>detection limit 2<i>σ</i><sub>Δ</sub>", "Resolution\n$\\Delta s_\\mathrm{r}$, $\\sigma_\\Delta$\ndetection limit 2$\\sigma_\\Delta$"),
 ("cmp", 1190, 480, ORANGE, "<b>Comparison</b><br>Δ<i>s</i><sub>r</sub> against Δ<i>R</i><sub>s</sub><br>pre-specified criteria", "Comparison\n$\\Delta s_\\mathrm{r}$ against $\\Delta R_\\mathrm{s}$\npre-specified criteria"),
]
# uncertainty inputs (italic, orange text) placed under the boxes they act on
NOTES = [
 ("n1", 150, 150, "<i>T</i><sub>ref</sub> not released", "$T_\\mathrm{ref}$ not released"),
 ("n2", 650, 150, "<i>c</i> = RefA/RefRefA, <i>δ</i><sub>rep</sub> ±0.5%<br><i>T</i>, <i>γ</i>, test contact", "$c$ = RefA/RefRefA, $\\delta_\\mathrm{rep}$ ±0.5%\n$T$, $\\gamma$, test contact"),
 ("n3", 930, 150, "exposure time, working distance", "exposure time, working distance"),
 ("n4", 225, 380, "<i>δ</i><sub>ext</sub> = 0.035%", "$\\delta_\\mathrm{ext}$ = 0.035%"),
 ("n5", 1190, 380, "robustness checks, Table 7", "robustness checks, Table 7"),
]
LANES = [("Measurement chain", 60, BLUE), ("Uncertainty analysis", 290, AQUA), ("EL analysis", 480, ORANGE)]
E_ = [("ref", "exp"), ("exp", "iv"), ("iv", "el"), ("iv", "ext"), ("ext", "pair"), ("pair", "corr"), ("corr", "mc"), ("mc", "out"),
      ("el", "seg"), ("seg", "map"), ("map", "res"), ("res", "cmp")]
DASHED = [("ext", "cmp")]
box = {b[0]: b for b in B}

# ---------------- draw.io XML
cells = ['<mxCell id="0"/>', '<mxCell id="1" parent="0"/>']
for name, y, c in LANES:
    cells.append(f'<mxCell id="lane_{y}" value="{html.escape("<b>" + name + "</b>")}" style="text;html=1;align=right;verticalAlign=middle;fontFamily=Helvetica;fontSize=13;fontColor={c};" vertex="1" parent="1"><mxGeometry x="0" y="{y}" width="138" height="{H}" as="geometry"/></mxCell>')
for k, x, y, c, lab, _ in B:
    st = f"rounded=1;arcSize=12;whiteSpace=wrap;html=1;fillColor={FILL[c]};strokeColor={c};strokeWidth=1.2;fontFamily=Helvetica;fontSize=12;fontColor={INK};spacing=4;"
    cells.append(f'<mxCell id="{k}" value="{html.escape(lab)}" style="{st}" vertex="1" parent="1"><mxGeometry x="{x}" y="{y}" width="{W}" height="{H}" as="geometry"/></mxCell>')
for k, x, y, lab, _ in NOTES:
    st = f"text;html=1;align=center;verticalAlign=middle;whiteSpace=wrap;fontFamily=Helvetica;fontSize=11;fontColor={ORANGE};fontStyle=2;"
    cells.append(f'<mxCell id="{k}" value="{html.escape(lab)}" style="{st}" vertex="1" parent="1"><mxGeometry x="{x - 20}" y="{y}" width="{W + 40}" height="40" as="geometry"/></mxCell>')
ROUTE = {("iv", "ext"): ("exitX=0.95;exitY=1;entryX=0.5;entryY=0;", [(670 + 0.95 * 230, 250), (265, 250)]),
         ("el", "seg"): ("exitX=1;exitY=0.5;entryX=0;entryY=0.5;", [(1185, 102), (1185, 440), (385, 440), (385, 522)]),
         ("ext", "cmp"): ("exitX=0.5;exitY=1;entryX=0.5;entryY=1;", [(265, 588), (1305, 588)])}
def edge(i, s, t, dashed=False):
    extra, pts = ROUTE.get((s, t), ("exitX=1;exitY=0.5;entryX=0;entryY=0.5;", []))
    st = f"edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;endArrow=block;endFill=1;strokeColor={GREY if dashed else INK};strokeWidth=1.2;" + extra + ("dashed=1;" if dashed else "")
    arr = ('<Array as="points">' + "".join(f'<mxPoint x="{x:.0f}" y="{y:.0f}"/>' for x, y in pts) + '</Array>') if pts else ""
    return f'<mxCell id="e{i}" style="{st}" edge="1" parent="1" source="{s}" target="{t}"><mxGeometry relative="1" as="geometry">{arr}</mxGeometry></mxCell>'
for i, (s, t) in enumerate(E_): cells.append(edge(i, s, t))
for j, (s, t) in enumerate(DASHED): cells.append(edge(100 + j, s, t, True))
xml = ('<mxfile host="app.diagrams.net"><diagram id="fig1" name="Fig. 1 Test procedure and analysis chain">'
       '<mxGraphModel dx="1400" dy="700" grid="0" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1460" pageHeight="610" background="#ffffff" math="0" shadow="0">'
       '<root>' + "".join(cells) + '</root></mxGraphModel></diagram></mxfile>')
open(os.path.join(OUT, "Fig1_test_procedure_analysis_chain.drawio"), "w").write(xml)

# ---------------- matching preview (PNG/PDF)
plt.rcParams.update({"font.family": "DejaVu Sans", "mathtext.default": "it", "mathtext.fontset": "dejavusans"})
fig, ax = plt.subplots(figsize=(13.6, 5.6)); ax.set_xlim(0, 1440); ax.set_ylim(600, 30); ax.axis("off")
for name, y, c in LANES:
    ax.text(138, y + H / 2, name, ha="right", va="center", fontsize=10, color=c, fontweight="bold")
for k, x, y, c, _, lab in B:
    ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle="round,pad=0,rounding_size=10", fc=FILL[c], ec=c, lw=1.1))
    l = lab.split("\n")
    ax.text(x + W / 2, y + 20, l[0], ha="center", va="center", fontsize=9, fontweight="bold", color=INK)
    ax.text(x + W / 2, y + 54, "\n".join(l[1:]), ha="center", va="center", fontsize=8, color=INK, linespacing=1.5)
for k, x, y, _, lab in NOTES:
    ax.text(x + W / 2, y + 20, lab, ha="center", va="center", fontsize=8, color=ORANGE, style="italic", linespacing=1.4)
def c_(k, side):
    _, x, y, *_ = box[k]
    return {"r": (x + W, y + H / 2), "l": (x, y + H / 2), "b": (x + W / 2, y + H), "t": (x + W / 2, y)}[side]
def arrow(p, q, ls="-", col=INK):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=11, lw=1.1, color=col, linestyle=ls, shrinkA=0, shrinkB=0))
for s, t in E_:
    if s == "iv" and t == "ext":
        p = (670 + 0.95 * W, 60 + H); q = c_("ext", "t"); m = 250
        ax.plot([p[0], p[0], q[0]], [p[1], m, m], color=INK, lw=1.1); arrow((q[0], m), q)
    elif s == "el" and t == "seg":
        p = c_("el", "r"); q = c_("seg", "l"); xr = p[0] + 25; ym = 440
        ax.plot([p[0], xr, xr, q[0] - 25, q[0] - 25], [p[1], p[1], ym, ym, q[1]], color=INK, lw=1.1); arrow((q[0] - 25, q[1]), q)
    else:
        arrow(c_(s, "r"), c_(t, "l"))
p = c_("ext", "b"); q = c_("cmp", "b"); yb = 588
ax.plot([p[0], p[0], q[0]], [p[1], yb, yb], color=GREY, lw=1.0, ls="--"); arrow((q[0], yb), q, "--", GREY)
fig.savefig(os.path.join(OUT, "Fig1_preview.png"), dpi=300, bbox_inches="tight", facecolor="white")
fig.savefig(os.path.join(OUT, "Fig1_preview.pdf"), bbox_inches="tight", facecolor="white")
print("ok")
