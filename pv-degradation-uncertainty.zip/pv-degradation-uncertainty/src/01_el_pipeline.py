"""
PV-IV-EL  -  EL decision pipeline (RQ2: is Rs growth intrinsic to the module?  RQ3: where is it?)

Usage: PV_BASE=/path/to/data python src/01_el_pipeline.py [--limit N] [--qc-every K]
(or in Google Colab after mounting Drive; copying EL.zip to /content first speeds up random access). Reads TIFFs straight out of EL.zip (no full unzip),
rectifies each module, splits it into cells, computes series-resistance-sensitive features from the
high (80% Isc) and low (20% Isc) bias images, pairs the first and last EL visit of every module,
joins the visit-to-visit IV change in Rs, and prints a pre-registered decision report.

Outputs (written to OUT):
  qc/                         overlay PNGs of the detected grid (check these first!)
  el_cell_features.csv        one row per image pair (H+L) per cell
  el_module_features.csv      one row per EL visit
  el_visit_pairs.csv          first-vs-last EL visit deltas joined with IV deltas
  delta_maps/                 average within-cell change maps per model (RQ3 localisation)
  decision_report.txt
"""
import os, io, re, glob, zipfile, json, warnings
import numpy as np, pandas as pd
import cv2, tifffile
from scipy import stats
from scipy.ndimage import uniform_filter1d

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------------------------------------
# configuration
# ----------------------------------------------------------------------------------------------
if "PV_BASE" in os.environ:
    BASE = os.environ["PV_BASE"]
elif os.path.exists("/content/drive"):
    BASE = next(p for p in glob.glob(os.environ.get("PV_DRIVE_GLOB", "/content/drive/MyDrive/Research/Solar*"))
                if os.path.isdir(p))
else:
    BASE = "data"
LOCAL_ZIP = "/content/EL.zip" if os.path.exists("/content/EL.zip") else os.path.join(BASE, "EL.zip")  # local copy is faster in Colab
OUT = os.path.join(BASE, "el_out")
CELL_PX = 64                             # each cell resampled to CELL_PX x CELL_PX for maps
INSET = 0.06                             # fraction of cell trimmed at each edge (avoid inter-cell gaps)
LOW_VALID = 0.25                         # pixels with L/mean_L below this are treated as inactive
EXCLUDE_MODELS = {"32-2", "38-4"}        # reference-IV anomalies found in the IV audit
GRID_OVERRIDE = {}                       # legacy equal-division grid (not used by the line-based detector)
MIN_ALIGN_RHO = 0.6                      # cell-pattern correlation needed to accept a visit-to-visit match
os.makedirs(OUT, exist_ok=True)
for d in ["qc", "delta_maps"]:
    os.makedirs(os.path.join(OUT, d), exist_ok=True)


# ----------------------------------------------------------------------------------------------
# metadata and pair selection
# ----------------------------------------------------------------------------------------------
def load_meta(base=BASE):
    a = pd.read_csv(os.path.join(base, "AnonDB.csv"))
    a["days"] = a.Total_Exposure.str.extract(r"(\d+)").astype(float)
    a["model_id"] = a.Make.astype(str) + "-" + a.Model.astype(str)
    a["ivf"] = a.IVPath.str.split("/").str[-1]
    a["elh"] = a.ELHPath.str.split("/").str[-1]
    a["ell"] = a.ELLPath.str.split("/").str[-1]
    a = a.dropna(subset=["elh", "ell"]).drop_duplicates("elh")
    a = a[~a.model_id.isin(EXCLUDE_MODELS)]
    return a


def select_visits(a):
    """Modules with >=2 EL visits -> keep first and last visit."""
    g = a.sort_values("days").groupby("Mod_ID")
    keep = g.filter(lambda x: len(x) >= 2)
    first = keep.groupby("Mod_ID").head(1)
    last = keep.groupby("Mod_ID").tail(1)
    return pd.concat([first, last]).sort_values(["Mod_ID", "days"])


# ----------------------------------------------------------------------------------------------
# image IO
# ----------------------------------------------------------------------------------------------
class ELZip:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)
        self.index = {os.path.basename(n): n for n in self.z.namelist()
                      if n.lower().endswith((".tif", ".tiff")) and "__MACOSX" not in n}

    def read(self, base_name):
        raw = self.z.read(self.index[base_name])
        try:                          # Pillow decodes the LZW-compressed EL TIFFs without imagecodecs
            from PIL import Image
            img = np.array(Image.open(io.BytesIO(raw)))
        except Exception:
            img = tifffile.imread(io.BytesIO(raw))
        if img.ndim == 3:                     # RGB or multi-channel -> single plane
            img = img.mean(axis=2) if img.shape[-1] <= 4 else img[0]
        return img.astype(np.float32)


# ----------------------------------------------------------------------------------------------
# module rectification and grid detection
# ----------------------------------------------------------------------------------------------
def _to8(img):
    lo, hi = np.percentile(img, [1, 99.5])
    return np.clip((img - lo) / (hi - lo + 1e-9) * 255, 0, 255).astype(np.uint8)


def _order(pts):
    s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], np.float32)


def find_module_quad(img_high):
    """Return 4 corner points (tl, tr, br, bl) of the bright module area."""
    im = cv2.GaussianBlur(_to8(img_high), (0, 0), 3)
    _, th = cv2.threshold(im, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    k = max(15, int(min(im.shape) * 0.03)) | 1
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    c = max(cnts, key=cv2.contourArea)
    approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
    pts = approx.reshape(-1, 2) if len(approx) == 4 else cv2.boxPoints(cv2.minAreaRect(c))
    return _order(np.asarray(pts, np.float32))


def warp(img, quad, short_px=1200):
    tl, tr, br, bl = quad
    w = (np.linalg.norm(tr - tl) + np.linalg.norm(br - bl)) / 2
    h = (np.linalg.norm(bl - tl) + np.linalg.norm(br - tr)) / 2
    scale = short_px / min(w, h)
    W, H = int(round(w * scale)), int(round(h * scale))
    M = cv2.getPerspectiveTransform(quad, np.float32([[0, 0], [W - 1, 0], [W - 1, H - 1], [0, H - 1]]))
    out = cv2.warpPerspective(img, M, (W, H), flags=cv2.INTER_AREA)
    if H > W:                                  # canonical: landscape, long axis = columns
        out = cv2.rotate(out, cv2.ROTATE_90_CLOCKWISE)
    return out


def _refine(profile, n):
    """Equal division into n segments, each internal boundary snapped to the darkest nearby point (override path)."""
    L = len(profile)
    p = uniform_filter1d(profile, max(3, L // (n * 25)))
    pitch = L / n
    b = [0]
    for i in range(1, n):
        g, r = int(i * pitch), int(pitch * 0.3)
        lo, hi = max(1, g - r), min(L - 1, g + r)
        b.append(lo + int(np.argmin(p[lo:hi])))
    b.append(L)
    return np.array(b)


def _sharpness(img_small):
    """Higher when inter-cell gaps are axis-aligned (sharp dips in both projection profiles)."""
    return np.var(np.diff(img_small.mean(1))) + np.var(np.diff(img_small.mean(0)))


def _rotate(img, ang):
    h, w = img.shape
    M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0)
    return cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)


def deskew_angle(img, max_deg=3.0):
    """Residual rotation (deg) that makes the cell gaps axis-aligned; coarse-to-fine search."""
    f = 1000 / max(img.shape)
    small = cv2.resize(img, None, fx=f, fy=f, interpolation=cv2.INTER_AREA)
    best = max(np.arange(-max_deg, max_deg + 1e-9, 0.1), key=lambda a: _sharpness(_rotate(small, a)))
    return max(np.arange(best - 0.1, best + 0.1001, 0.02), key=lambda a: _sharpness(_rotate(small, a)))


def _pitch(profile, n_min, n_max):
    """Dominant cell pitch (px) from the autocorrelation of the detrended profile."""
    L = len(profile)
    p = profile - uniform_filter1d(profile, max(5, L // 4))
    p = (p - p.mean()) / (p.std() + 1e-9)
    ac = np.correlate(p, p, mode="full")[L - 1:] / L
    lo, hi = int(L / n_max * 0.85), int(L / n_min * 1.15)
    return lo + int(np.argmax(ac[lo:hi]))


def _gaps(profile, pitch, fills_frame=False):
    """Boundaries at the dark inter-cell gaps: fit lattice phase, snap to local minima, keep only full cells.
    fills_frame=True: the module runs past the image edge, so edge segments are partial unless ~full length."""
    L = len(profile)
    p = uniform_filter1d(profile, max(3, pitch // 40))
    phase = min(range(pitch), key=lambda ph: p[ph::pitch].mean())
    w = max(2, int(pitch * 0.12))
    b = []
    for g in range(phase, L, pitch):
        lo, hi = max(0, g - w), min(L, g + w + 1)
        b.append(lo + int(np.argmin(p[lo:hi])))
    b = sorted(set(b))
    # an outer edge counts as a boundary only if a full cell fits between it and the first/last gap
    edge = 0.92 if fills_frame else 0.70
    if b[0] >= edge * pitch:
        b.insert(0, max(0, b[0] - pitch))
    if L - b[-1] >= edge * pitch:
        b.append(min(L, b[-1] + pitch))
    b = np.array(b)
    seg = np.diff(b)
    keep = (seg > 0.70 * pitch) & (seg < 1.25 * pitch)         # drop merged segments
    if fills_frame and keep.size:                               # stricter on the outermost segments
        keep[0] &= seg[0] > edge * pitch
        keep[-1] &= seg[-1] > edge * pitch
    out = [b[0]] if keep.size and keep[0] else []
    for i, k in enumerate(keep):
        if k:
            if not out or out[-1] != b[i]:
                out.append(b[i])
            out.append(b[i + 1])
    return np.array(out)


def touches_frame(quad, shape, tol=0.01):
    """True if the detected module outline reaches the image border (module fills/overflows the frame)."""
    h, w = shape
    x, y = quad[:, 0], quad[:, 1]
    return bool((x.min() < tol * w) or (x.max() > (1 - tol) * w) or (y.min() < tol * h) or (y.max() > (1 - tol) * h))


def detect_grid(warped, model_id=None, fills_frame=False):
    """Return row and column boundary arrays. Rows: 5-8 cells; columns: 9-26 cells (full or half-cut)."""
    if model_id in GRID_OVERRIDE:
        nr, nc = GRID_OVERRIDE[model_id]
        return _refine(warped.mean(1), nr), _refine(warped.mean(0), nc)
    rp, cp = warped.mean(1), warped.mean(0)
    return (_gaps(rp, _pitch(rp, 5, 8), fills_frame),
            _gaps(cp, _pitch(cp, 9, 26), fills_frame))



# ----------------------------------------------------------------------------------------------
# line-based grid: each inter-cell gap is its own straight line (handles tilt, keystone, pitch drift)
# ----------------------------------------------------------------------------------------------
from scipy.signal import find_peaks


def _pitch_ac(profile, n_min, n_max):
    """Cell pitch from the autocorrelation; the smallest lag whose peak is >= 0.8 of the best wins
    (so a half-cut module is not mistaken for full cells at twice the pitch)."""
    L = len(profile)
    p = profile - uniform_filter1d(profile, max(5, L // 4))
    p = (p - p.mean()) / (p.std() + 1e-9)
    ac = np.correlate(p, p, mode="full")[L - 1:] / L
    lo, hi = int(L / n_max * 0.85), min(L - 1, int(L / n_min * 1.15))
    seg = ac[lo:hi]
    pk, _ = find_peaks(seg)
    if not len(pk):
        return lo + int(np.argmax(seg))
    best = seg[pk].max()
    return lo + int(pk[seg[pk] >= 0.8 * best].min())


def _dark_lines(img8, pitch, horizontal):
    """Enhance thin dark straight structures along one direction (gaps; also busbars/fingers)."""
    k = max(3, int(pitch * 0.20)) | 1          # wider than any inter-cell gap, incl. half-cut pitch
    bh = cv2.morphologyEx(img8, cv2.MORPH_BLACKHAT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    ln = max(5, int(pitch * 0.45))
    ker = cv2.getStructuringElement(cv2.MORPH_RECT, (ln, 1) if horizontal else (1, ln))
    return cv2.morphologyEx(bh, cv2.MORPH_OPEN, ker).astype(np.float32)


def _fit_lines(resp, pitch, horizontal, n_strips=9):
    """Find gap lines as peaks in strip-wise profiles, link them across strips, fit pos = a*t + b."""
    if not horizontal:
        resp = resp.T                                     # work in 'horizontal line' coordinates
    H, W = resp.shape
    edges = np.linspace(0, W, n_strips + 1).astype(int)
    centres = (edges[:-1] + edges[1:]) / 2
    peaks, profs = [], []
    for s in range(n_strips):
        prof = uniform_filter1d(resp[:, edges[s]:edges[s + 1]].mean(1), max(3, pitch // 30))
        pk, pr = find_peaks(prof, distance=int(0.7 * pitch), prominence=prof.std() * 0.5)
        peaks.append(pk)
        profs.append(prof)
    mid = n_strips // 2
    lines = []
    for y0 in peaks[mid]:
        pts = [(centres[mid], y0)]
        strength = [profs[mid][y0]]
        for direction in (range(mid + 1, n_strips), range(mid - 1, -1, -1)):
            y = y0
            for s in direction:
                if not len(peaks[s]):
                    continue
                j = np.argmin(np.abs(peaks[s] - y))
                if abs(peaks[s][j] - y) < 0.25 * pitch:
                    y = peaks[s][j]
                    pts.append((centres[s], y))
                    strength.append(profs[s][y])
        if len(pts) >= max(4, int(0.6 * n_strips)):
            t, y = np.array(pts).T
            a, b = np.polyfit(t, y, 1)
            res = np.abs(y - (a * t + b))
            if res.max() > 0.1 * pitch and len(pts) > 5:     # one robust refit without the worst point
                keep = res < res.max()
                a, b = np.polyfit(t[keep], y[keep], 1)
            lines.append((a, b, float(np.mean(strength))))
    lines = sorted(lines, key=lambda l: l[0] * W / 2 + l[1])
    return lines, W, H


def _keep_cell_gaps(lines, W, pitch):
    """Busbars/ribbons can also form lines. Gaps are the darkest structures, so keep lines strongest-first
    and suppress anything closer than 0.75 pitch to an already accepted line."""
    if len(lines) < 2:
        return [(a, b) for a, b, _ in lines]
    pos = np.array([a * W / 2 + b for a, b, _ in lines])
    order = np.argsort([-l[2] for l in lines])
    acc = []
    for i in order:
        if all(abs(pos[i] - pos[j]) > 0.75 * pitch for j in acc):
            acc.append(i)
    acc = sorted(acc, key=lambda i: pos[i])
    # lattice check: every kept line must sit ~one pitch from a neighbour; trim off-lattice ends
    ok = lambda d: 0.8 * pitch <= d <= 1.25 * pitch
    changed = True
    while changed and len(acc) >= 2:
        changed = False
        if not ok(pos[acc[1]] - pos[acc[0]]):
            acc.pop(0); changed = True; continue
        if not ok(pos[acc[-1]] - pos[acc[-2]]):
            acc.pop(); changed = True; continue
        for k in range(1, len(acc) - 1):
            if not ok(pos[acc[k]] - pos[acc[k - 1]]) and not ok(pos[acc[k + 1]] - pos[acc[k]]):
                acc.pop(k); changed = True; break
    return [(lines[i][0], lines[i][1]) for i in acc]


def _add_edges(lines, W, L, pitch, fills_frame):
    """Bordered module: its outer edges are cell boundaries. Frame-filling: edge strips are partial cells."""
    if fills_frame or not lines:
        return lines
    first = lines[0][0] * W / 2 + lines[0][1]
    last = lines[-1][0] * W / 2 + lines[-1][1]
    if first > 0.7 * pitch:
        lines = [(0.0, max(0.0, first - pitch))] + lines
    if L - last > 0.7 * pitch:
        lines = lines + [(0.0, min(L - 1.0, last + pitch))]
    return lines


def _off_border(lines, W, L, pitch, margin=0.15, full=0.95):
    """Frame-filling module: a line hugging the frame border is dropped when the cell it bounds is short
    (a cut-off cell). A real gap near the border bounds a full-pitch cell and is kept."""
    if len(lines) < 2:
        return lines
    mid = lambda l: l[0] * W / 2 + l[1]
    ends = lambda l: (l[1], l[0] * W + l[1])
    out = list(lines)
    if min(ends(out[0])) < margin * pitch and mid(out[1]) - mid(out[0]) < full * pitch:
        out.pop(0)
    if len(out) >= 2 and max(ends(out[-1])) > L - margin * pitch and mid(out[-1]) - mid(out[-2]) < full * pitch:
        out.pop()
    return out


def build_grid(warped, fills_frame=False):
    """Return (row_lines, col_lines): rows as y = a*x + b, columns as x = c*y + d."""
    img8 = _to8(warped)
    rp = _pitch_ac(warped.mean(1), 4, 9)
    cp = _pitch_ac(warped.mean(0), 8, 26)
    hr, W, Hh = _fit_lines(_dark_lines(img8, rp, True), rp, True)
    vc, Hv, Wv = _fit_lines(_dark_lines(img8, cp, False), cp, False)
    hr = _keep_cell_gaps(hr, W, rp)
    vc = _keep_cell_gaps(vc, Hv, cp)
    if fills_frame:                       # a 'gap' hugging the frame border only bounds a cut-off cell
        hr = _off_border(hr, W, Hh, rp)
        vc = _off_border(vc, Hv, Wv, cp)
    hr = _add_edges(hr, W, Hh, rp, fills_frame)
    vc = _add_edges(vc, Hv, Wv, cp, fills_frame)
    return hr, vc, rp, cp


def _cross(h, v):
    a, b = h
    c, d = v
    y = (a * d + b) / (1 - a * c)
    return np.float32([c * y + d, y])


def cell_quads(hr, vc):
    quads = {}
    for i in range(len(hr) - 1):
        for j in range(len(vc) - 1):
            quads[(i, j)] = np.stack([_cross(hr[i], vc[j]), _cross(hr[i], vc[j + 1]),
                                      _cross(hr[i + 1], vc[j + 1]), _cross(hr[i + 1], vc[j])])
    return quads


def warp_cell(img, q):
    T = int(round(CELL_PX / (1 - 2 * INSET)))
    M = cv2.getPerspectiveTransform(q, np.float32([[0, 0], [T - 1, 0], [T - 1, T - 1], [0, T - 1]]))
    t = cv2.warpPerspective(img, M, (T, T), flags=cv2.INTER_AREA)
    o = (T - CELL_PX) // 2
    return t[o:o + CELL_PX, o:o + CELL_PX]

# ----------------------------------------------------------------------------------------------
# features
# ----------------------------------------------------------------------------------------------
def background(img, quad):
    mask = np.zeros(img.shape, np.uint8)
    cv2.fillConvexPoly(mask, quad.astype(np.int32), 1)
    out = img[mask == 0]
    return float(np.median(out)) if out.size else 0.0


def cell_tiles(warped, rb, cb):
    tiles = []
    for i in range(len(rb) - 1):
        for j in range(len(cb) - 1):
            r0, r1, c0, c1 = rb[i], rb[i + 1], cb[j], cb[j + 1]
            dr, dc = int((r1 - r0) * INSET), int((c1 - c0) * INSET)
            t = warped[r0 + dr:r1 - dr, c0 + dc:c1 - dc]
            tiles.append(((i, j), cv2.resize(t, (CELL_PX, CELL_PX), interpolation=cv2.INTER_AREA)))
    return tiles


def cell_features(tH, tL):
    mH, mL = tH.mean() + 1e-9, tL.mean() + 1e-9
    nH, nL = tH / mH, tL / mL
    valid = nL > LOW_VALID
    r = np.full_like(nH, np.nan)
    r[valid] = np.log((nH[valid] + 1e-6) / (nL[valid] + 1e-6))
    rv = r[valid]
    return dict(
        mH=mH, mL=mL,
        ln_HL=np.log(mH / mL),                        # cell junction-voltage step (J0 / ideality)
        rs_std=np.nanstd(rv) if rv.size else np.nan,  # Rs-induced lateral inhomogeneity (grows with current)
        rs_dark=np.mean(rv < -0.10) if rv.size else np.nan,  # area darker at high bias than at low bias
        rs_p05=np.nanpercentile(rv, 5) if rv.size else np.nan,
        inactive=np.mean(nH < 0.30),                  # crack-isolated / dead area
        cv_H=nH.std(),
    ), r


def process_visit(elz, row, save_qc=False):
    H = elz.read(row.elh)
    Lw = elz.read(row.ell)
    quad = find_module_quad(H)
    ff = touches_frame(quad, H.shape)
    H = H - background(H, quad)
    Lw = Lw - background(Lw, quad)
    wH, wL = warp(H, quad), warp(Lw, quad)
    hr, vc, rp, cp = build_grid(wH, fills_frame=ff)
    quads = cell_quads(hr, vc)
    grid = (len(hr) - 1, len(vc) - 1)
    if grid[0] < 3 or grid[1] < 6:
        print(f"  WARNING small grid {grid[0]}x{grid[1]} for {row.elh} - check QC")
    cells, rmaps = [], []
    for (i, j), q in quads.items():
        f, r = cell_features(warp_cell(wH, q), warp_cell(wL, q))
        f.update(row=i, col=j)
        cells.append(f)
        rmaps.append(r)
    cdf = pd.DataFrame(cells)
    cdf["ln_HL_rel"] = cdf.ln_HL - cdf.ln_HL.median()
    cdf["mH_rel"] = cdf.mH / cdf.mH.median()
    if save_qc:
        vis = cv2.cvtColor(_to8(wH), cv2.COLOR_GRAY2BGR)
        Hh, Ww = wH.shape
        for a, b in hr:
            cv2.line(vis, (0, int(b)), (Ww, int(a * Ww + b)), (0, 0, 255), 2)
        for c, d in vc:
            cv2.line(vis, (int(d), 0), (int(c * Hh + d), Hh), (0, 0, 255), 2)
        cv2.imwrite(os.path.join(OUT, "qc", f"{row.Mod_ID}_{row.model_id}_{int(row.days)}d.jpg"),
                    cv2.resize(vis, None, fx=0.5, fy=0.5))
    return cdf, np.stack(rmaps), grid


def module_summary(cdf):
    return dict(
        n_cells=len(cdf),
        rs_std_med=cdf.rs_std.median(), rs_std_p90=cdf.rs_std.quantile(0.9),
        rs_dark_mean=cdf.rs_dark.mean(), rs_p05_med=cdf.rs_p05.median(),
        inactive_mean=cdf.inactive.mean(), inactive_max=cdf.inactive.max(),
        cellH_cv=cdf.mH_rel.std(), lnHL_spread=cdf.ln_HL_rel.std(),
    )


# ----------------------------------------------------------------------------------------------
# pairing: orientation alignment between visits
# ----------------------------------------------------------------------------------------------
TRANSFORMS = {"id": lambda m: m, "rot180": lambda m: m[::-1, ::-1],
              "flipud": lambda m: m[::-1, :], "fliplr": lambda m: m[:, ::-1]}


def align(c1, g1, c2, g2, max_shift=3, min_frac=0.6):
    """Match the cell grid of visit 2 to visit 1: orientation (4 flips) x integer shift.
    Framing can differ between visits (frame-filling modules show different full cells), so only the
    overlapping cells are compared. Score = correlation of the persistent cell-brightness pattern."""
    M1 = c1.mH_rel.values.reshape(g1)
    best = None
    for t, T in TRANSFORMS.items():
        M2 = T(c2.mH_rel.values.reshape(g2))
        I2 = T(np.arange(len(c2)).reshape(g2))
        h2, w2 = M2.shape
        for dr in range(-max_shift, max_shift + 1):
            for dc in range(-max_shift, max_shift + 1):
                r0, r1_ = max(0, -dr), min(g1[0], h2 - dr)       # rows of visit 1 that exist in visit 2
                q0, q1_ = max(0, -dc), min(g1[1], w2 - dc)
                if r1_ - r0 < 2 or q1_ - q0 < 2:
                    continue
                n = (r1_ - r0) * (q1_ - q0)
                if n < max(12, min_frac * min(len(c1), len(c2))):
                    continue
                a = M1[r0:r1_, q0:q1_].ravel()
                b = M2[r0 + dr:r1_ + dr, q0 + dc:q1_ + dc].ravel()
                if a.std() < 1e-6 or b.std() < 1e-6:
                    continue
                rho = np.corrcoef(a, b)[0, 1]
                if best is None or rho > best[0]:
                    i1 = np.arange(len(c1)).reshape(g1)[r0:r1_, q0:q1_].ravel()
                    i2 = I2[r0 + dr:r1_ + dr, q0 + dc:q1_ + dc].ravel()
                    best = (rho, t, dr, dc, i1, i2, (r1_ - r0, q1_ - q0))
    if best is None or best[0] < MIN_ALIGN_RHO:          # never compare cells that are not the same cells
        return None
    return best


# ----------------------------------------------------------------------------------------------
# IV deltas between the same two visits (reference-independent)
# ----------------------------------------------------------------------------------------------
def iv_lookup(base=BASE):
    p = pd.read_csv(os.path.join(base, "iv_params.csv"))
    return p[p.kind == "IV"].set_index("file")[["Isc", "Voc", "Pmp", "FF", "Rs0", "Rsh0", "sd_Rs"]]


# ----------------------------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------------------------
def run(zip_path=LOCAL_ZIP, limit=None, qc_every=10):
    a = load_meta()
    v = select_visits(a)
    if limit:
        v = v[v.Mod_ID.isin(v.Mod_ID.unique()[:limit])]
    elz = ELZip(zip_path)
    missing = set(v.elh) - set(elz.index) | set(v.ell) - set(elz.index)
    print(f"modules {v.Mod_ID.nunique()}, visits {len(v)}, missing images {len(missing)}")
    v = v[v.elh.isin(elz.index) & v.ell.isin(elz.index)]

    cache_mod = os.path.join(OUT, "el_module_features.csv")
    done = set(pd.read_csv(cache_mod).elh) if os.path.exists(cache_mod) else set()
    store = {}
    for n, row in enumerate(v.itertuples()):
        key = row.elh
        try:
            cdf, rmaps, grid = process_visit(elz, row, save_qc=(n % qc_every == 0))
        except Exception as ex:
            print("FAIL", row.Mod_ID, row.elh, ex)
            continue
        store[key] = (cdf, rmaps, grid)
        if key not in done:
            ms = module_summary(cdf)
            ms.update(Mod_ID=row.Mod_ID, model_id=row.model_id, days=row.days, elh=row.elh, ivf=row.ivf,
                      grid=f"{grid[0]}x{grid[1]}")
            pd.DataFrame([ms]).to_csv(cache_mod, mode="a", header=not os.path.exists(cache_mod), index=False)
            cdf.assign(elh=row.elh, Mod_ID=row.Mod_ID).to_csv(
                os.path.join(OUT, "el_cell_features.csv"), mode="a",
                header=not os.path.exists(os.path.join(OUT, "el_cell_features.csv")), index=False)
        if n % 25 == 0:
            print(f"  {n}/{len(v)}")
    return v, store


def pair_and_test(v, store):
    iv = iv_lookup()
    rows, maps, skipped = [], {}, 0
    for mod, g in v.groupby("Mod_ID"):
        g = g.sort_values("days")
        k1, k2 = g.elh.iloc[0], g.elh.iloc[-1]
        if k1 not in store or k2 not in store:
            continue
        (c1, r1, g1), (c2, r2, g2) = store[k1], store[k2]
        al = align(c1, g1, c2, g2)
        if al is None:
            skipped += 1
            continue
        rho, t, dr, dc, i1, i2, ov = al
        c1o = c1.iloc[i1].reset_index(drop=True)
        c2o = c2.iloc[i2].reset_index(drop=True)
        r1o = r1[i1]
        r2o = {"id": lambda x: x, "rot180": lambda x: x[:, ::-1, ::-1], "flipud": lambda x: x[:, ::-1, :],
               "fliplr": lambda x: x[:, :, ::-1]}[t](r2[i2])         # a module flip also flips each tile
        model = g.model_id.iloc[0]
        if rho > 0.8:                      # only tightly aligned pairs contribute to localisation maps
            maps.setdefault(model, []).append(np.nanmean(r2o - r1o, axis=0))
        m1, m2 = module_summary(c1o), module_summary(c2o)
        d = {f"d_{k}": m2[k] - m1[k] for k in m1 if k != "n_cells"}
        d.update({f"v1_{k}": m1[k] for k in ("rs_std_med", "rs_dark_mean", "inactive_mean")})
        dcell = c2o.rs_std.values - c1o.rs_std.values
        d.update(frac_cells_rs_up=np.mean(dcell > 0.01), d_rs_std_cell_p90=np.nanpercentile(dcell, 90))
        f1, f2 = g.ivf.iloc[0], g.ivf.iloc[-1]
        if f1 in iv.index and f2 in iv.index:
            a1, a2 = iv.loc[f1], iv.loc[f2]
            d.update(dRs_abs=a2.Rs0 - a1.Rs0, dRs_rel=(a2.Rs0 / a1.Rs0 - 1) * 100,
                     dFF=a2.FF - a1.FF, dPmp=(a2.Pmp / a1.Pmp - 1) * 100,
                     dIsc=(a2.Isc / a1.Isc - 1) * 100, dVoc=(a2.Voc / a1.Voc - 1) * 100)
        d.update(Mod_ID=mod, model_id=model, days1=g.days.iloc[0], days2=g.days.iloc[-1],
                 align=t, shift=f"{dr},{dc}", align_rho=rho, n_overlap=len(i1),
                 grid1=f"{g1[0]}x{g1[1]}", grid2=f"{g2[0]}x{g2[1]}")
        rows.append(d)
    P = pd.DataFrame(rows)
    print(f"paired {len(P)} modules; skipped {skipped} (no confident cell match between visits)")
    P.to_csv(os.path.join(OUT, "el_visit_pairs.csv"), index=False)
    save_maps(maps)
    return P


def save_maps(maps):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    models = sorted(maps, key=lambda m: -len(maps[m]))
    n = len(models)
    cols = min(5, n)
    rows = int(np.ceil(n / cols))
    fig, ax = plt.subplots(rows, cols, figsize=(max(6, 2.6 * cols), 2.6 * rows + 0.8), squeeze=False)
    for k, m in enumerate(models):
        avg = np.nanmean(np.stack(maps[m]), axis=0)
        np.save(os.path.join(OUT, "delta_maps", f"{m}.npy"), avg)
        a = ax[k // cols, k % cols]
        lim = np.nanpercentile(np.abs(avg), 98) or 0.01
        im = a.imshow(avg, cmap="RdBu_r", vmin=-lim, vmax=lim)
        a.set_title(f"{m} (n={len(maps[m])})", fontsize=8)
        a.axis("off")
    for k in range(n, rows * cols):
        ax[k // cols, k % cols].axis("off")
    fig.suptitle("Mean within-cell change of ln(H/L) map, last minus first visit\n"
                 "blue = darker at high bias than before (Rs-type loss)", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "delta_maps", "delta_maps_by_model.png"), dpi=150)
    plt.close(fig)


def decision_report(P):
    L = []
    say = L.append
    # module-level summaries are orientation-invariant, so all pairs are used for tests A-E;
    # every pair here already passed MIN_ALIGN_RHO; maps use the tighter rho > 0.8
    say(f"Module pairs: {len(P)}  models: {P.model_id.nunique()}  "
        f"tightly aligned (rho>0.8, used for maps): {(P.align_rho > 0.8).sum()}")
    say("Pre-registered criteria (set before looking at EL results):")
    say("  INTRINSIC Rs growth : median d_rs_std_med > 0 (sign test p<0.01) AND "
        "Spearman(d_rs_std_med, dRs_abs) >= 0.30 with p<0.01, or model-level rho >= 0.50")
    say("  SETUP ARTIFACT      : d_rs_std_med CI includes 0 AND |rho| < 0.10")
    say("  otherwise           : INCONCLUSIVE -> inspect delta maps")
    say("")
    x = P.d_rs_std_med.dropna()
    up = (x > 0).sum()
    p_sign = stats.binomtest(up, len(x), 0.5, alternative="greater").pvalue
    boot = [np.median(np.random.choice(x, len(x))) for _ in range(5000)]
    lo, hi = np.percentile(boot, [2.5, 97.5])
    say(f"[A] EL Rs-inhomogeneity change: median {x.median():+.4f} (95% CI {lo:+.4f}..{hi:+.4f}); "
        f"{up}/{len(x)} up; sign test p={p_sign:.2g}")
    q = P.dropna(subset=["d_rs_std_med", "dRs_abs"])
    rho, p = stats.spearmanr(q.d_rs_std_med, q.dRs_abs)
    say(f"[B] Module level Spearman(d_rs_std_med, dRs_abs) = {rho:.2f} (p={p:.2g}, n={len(q)})")
    for alt in ["d_rs_dark_mean", "d_rs_p05_med", "d_inactive_mean", "d_cellH_cv", "d_lnHL_spread"]:
        r2, p2 = stats.spearmanr(q[alt], q.dRs_abs, nan_policy="omit")
        r3, p3 = stats.spearmanr(q[alt], q.dFF, nan_policy="omit")
        say(f"      {alt:16s} vs dRs_abs rho={r2:+.2f} (p={p2:.2g}) | vs dFF rho={r3:+.2f} (p={p3:.2g})")
    # within-model (demeaned) association guards against model-level confounding
    qd = q.copy()
    for c in ["d_rs_std_med", "dRs_abs"]:
        qd[c] = qd[c] - qd.groupby("model_id")[c].transform("mean")
    rw, pw = stats.spearmanr(qd.d_rs_std_med, qd.dRs_abs)
    say(f"[C] Within-model Spearman = {rw:.2f} (p={pw:.2g})")
    mm = q.groupby("model_id").agg(n=("Mod_ID", "size"), el=("d_rs_std_med", "median"),
                                   rs=("dRs_abs", "median")).query("n>=4")
    rm, pm = stats.spearmanr(mm.el, mm.rs) if len(mm) >= 5 else (np.nan, np.nan)
    say(f"[D] Model level Spearman (models with >=4 pairs, k={len(mm)}) = {rm:.2f} (p={pm:.2g})")
    say(mm.round(4).to_string())
    # competing explanation: cracks / inactive area
    ri, pi = stats.spearmanr(q.d_inactive_mean, q.dFF, nan_policy="omit")
    say(f"[E] Competing mechanism - inactive (crack) area change vs dFF: rho={ri:.2f} (p={pi:.2g}); "
        f"modules with inactive area +1%pt or more: {(q.d_inactive_mean > 0.01).sum()}")
    intrinsic = (p_sign < 0.01 and x.median() > 0) and ((rho >= 0.30 and p < 0.01) or (rm >= 0.50))
    artifact = (lo <= 0 <= hi) and abs(rho) < 0.10
    verdict = "INTRINSIC Rs GROWTH SUPPORTED" if intrinsic else (
        "SETUP ARTIFACT SUPPORTED" if artifact else "INCONCLUSIVE - inspect delta_maps and QC overlays")
    say("")
    say("VERDICT: " + verdict)
    txt = "\n".join(L)
    open(os.path.join(OUT, "decision_report.txt"), "w").write(txt)
    print(txt)
    return verdict


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="EL processing: cell features, first-vs-last visit pairs, decision report")
    ap.add_argument("--zip", default=LOCAL_ZIP, help="path to EL.zip (default: /content/EL.zip or <PV_BASE>/EL.zip)")
    ap.add_argument("--limit", type=int, default=None, help="process only the first N modules (pilot run)")
    ap.add_argument("--qc-every", type=int, default=15, help="write a grid-overlay QC image every K visits")
    args = ap.parse_args()
    v, store = run(args.zip, limit=args.limit, qc_every=args.qc_every)
    print("processed visits:", len(store))
    P = pair_and_test(v, store)
    decision_report(P)
