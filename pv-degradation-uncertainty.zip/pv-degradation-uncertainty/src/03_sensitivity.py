"""Sensitivity and robustness analyses reported in Sec. 3.2, 4.5, 4.6, 4.8 and 4.9 and Table 7.

Runs the data-preparation part of 02_figures_tables.py (everything before the Monte Carlo section),
then computes:
  1. collinearity of the calibration ratio c and exposure t, the (c-1) x t interaction, and the I_sc coefficient;
  2. point-estimate sensitivities of the pooled rate (complete case, t >= 1 yr, outlier removal,
     free intercept, contact fraction f);
  3. per-model free-intercept fits, first-year exclusion and leave-one-module-out shifts;
  4. reference-date check;
  5. EL sensitivity for pairs with unchanged acquisition settings;
  6. imputation check, models with both c = 1 and c != 1, and a module bootstrap of the free-intercept model.

Requires 01_el_pipeline.py and 02_figures_tables.py to have been run (uses el_out/el_visit_pairs.csv and
paper_out/tables/T3_rates.csv in the data folder).

Usage: PV_BASE=/path/to/data python src/03_sensitivity.py
Outputs: <PV_BASE>/paper_out/sensitivity/sens.json, per_model_sens.csv, and a printed log.
"""
import os, numpy as np, pandas as pd, warnings, json
warnings.filterwarnings("ignore")
os.environ.setdefault("MPLBACKEND", "Agg")
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "02_figures_tables.py")).read()
exec(src[:src.index('print("Monte Carlo')])
SENS = os.path.join(BASE, "paper_out", "sensitivity"); os.makedirs(SENS, exist_ok=True)

# ================= Part 1: pooled and per-model sensitivities =================
import statsmodels.formula.api as smf
from scipy import stats
OUT = {}
# --- 1. collinearity of c and t, interaction (410 exposed measurements with c, all models)
q = m[(m.days > 0)].dropna(subset=["cal_ratio"]).copy(); q["cal"] = (q.cal_ratio - 1) * 100
OUT["n_q"] = len(q)
OUT["r_c_t"] = float(np.corrcoef(q.cal, q.yrs)[0, 1]); OUT["rho_c_t"] = float(stats.spearmanr(q.cal, q.yrs)[0])
OUT["VIF"] = 1 / (1 - OUT["r_c_t"] ** 2)
f0 = smf.mixedlm("dPmp ~ cal + yrs", q, groups=q.Mod_ID).fit()
f1 = smf.mixedlm("dPmp ~ cal * yrs", q, groups=q.Mod_ID).fit()
OUT["beta_main"] = [float(f0.params.cal), float(f0.bse.cal)]
OUT["interaction"] = [float(f1.params["cal:yrs"]), float(f1.bse["cal:yrs"]), float(f1.pvalues["cal:yrs"])]
OUT["beta_with_int"] = [float(f1.params.cal), float(f1.bse.cal)]
fi = smf.mixedlm("dIsc ~ cal + yrs", q, groups=q.Mod_ID).fit(); OUT["isc_coef"] = [float(fi.params.cal), float(fi.bse.cal)]
# only models that have both c=1 and c!=1 measurements at similar exposure? within 2021 campaign: compare
# --- 2. point-estimate sensitivities of pooled rate (scenario B definitions)
c_nom = np.where(np.isnan(cal), 1.0, cal)
yA = (P / P0 - 1) * 100; yB = (P / c_nom ** BETA / P0 - 1) * 100; yC = ((P / c_nom ** BETA + Imp ** 2 * dRs) / P0 - 1) * 100
def pooled(y, mask): return float(np.sum(y[mask] * t[mask]) / np.sum(t[mask] ** 2))
allm = np.ones(len(P), bool)
S = {}
S["B, all 444"] = (pooled(yB, allm), int(allm.sum()))
cc = ~np.isnan(cal); S["B, complete case (c recorded)"] = (pooled(yB, cc), int(cc.sum()))
same = np.isclose(c_nom, 1) & cc; S["Only c = 1 recorded"] = (pooled(yA, same), int(same.sum()))
S["A, all 444"] = (pooled(yA, allm), 444)
late = t >= 1; S["B, exposure >= 1 yr"] = (pooled(yB, late), int(late.sum()))
# drop two 22-4 extraction outliers (largest |extracted-published| Pmp)
dev = (e.Pmp / e["Pmp_(W)"] - 1).abs().values
out2 = np.argsort(-dev)[:2]; keep2 = allm.copy(); keep2[out2] = False
S["B, without two largest extraction outliers"] = (pooled(yB, keep2), int(keep2.sum()))
OUT["outlier_curves"] = e.iloc[out2][["Mod_ID", "model_id"]].astype(str).values.tolist() + [list(map(float, dev[out2]))]
el4 = e.Mod_ID.isin([3280, 3759, 4548, 4558]).values; S["B, without 4 EL outlier modules"] = (pooled(yB, ~el4), int((~el4).sum()))
# intercept model (L-shape): y = a + b t, pooled
X = np.c_[np.ones(len(t)), t]; a_, b_ = np.linalg.lstsq(X, yB, rcond=None)[0]
S["B, with free intercept (slope)"] = (float(b_), 444); OUT["intercept_B"] = float(a_)
# f equivalent to 4 mOhm common offset
f4 = 0.004 / np.median(dRs); OUT["f_4mOhm"] = float(f4)
S["f = 0.25"] = (pooled(yB + 0.25 * (yC - yB), allm), 444); S["f = 0.5"] = (pooled(yB + 0.5 * (yC - yB), allm), 444)
S[f"f = {f4:.2f} (4 mOhm common offset)"] = (pooled(yB + f4 * (yC - yB), allm), 444)
S["C (f = 1)"] = (pooled(yC, allm), 444)
OUT["pooled_sens"] = {k: [round(v[0], 3), v[1]] for k, v in S.items()}
# per-model intercept fits and linear-fit residual check
rows = []
for mm in models:
    k = (e.model_id == mm).values
    b0 = np.sum(yB[k] * t[k]) / np.sum(t[k] ** 2)
    Xk = np.c_[np.ones(k.sum()), t[k]]; coef, res, *_ = np.linalg.lstsq(Xk, yB[k], rcond=None)
    # leave-one-module-out
    lomo = []
    for mod in e.loc[k, "Mod_ID"].unique():
        kk = k & (e.Mod_ID != mod).values
        lomo.append(np.sum(yB[kk] * t[kk]) / np.sum(t[kk] ** 2))
    # first-year exclusion
    kl = k & (t >= 1)
    rows.append(dict(model=mm, Rd_B=b0, Rd_ge1yr=(np.sum(yB[kl] * t[kl]) / np.sum(t[kl] ** 2)) if kl.sum() >= 3 else np.nan,
                     n_ge1yr=int(kl.sum()), intercept=coef[0], slope_free=coef[1],
                     lomo_max_shift=float(np.max(np.abs(np.array(lomo) - b0))), rmse=float(np.sqrt(np.mean((yB[k] - b0 * t[k]) ** 2)))))
PM = pd.DataFrame(rows).set_index("model")
T3 = pd.read_csv(os.path.join(BASE, "paper_out", "tables", "T3_rates.csv"), index_col=0)
PM["U_B"] = T3.U_B_k2
PM["halfwidth_B"] = (T3.B_hi - T3.B_lo) / 2
PM["asym"] = ((T3.B_hi - T3.B) - (T3.B - T3.B_lo))
PM.round(3).to_csv(os.path.join(SENS, "per_model_sens.csv"))
OUT["pooled_halfwidth_vs_U"] = [float((T3.loc["Pooled", "B_hi"] - T3.loc["Pooled", "B_lo"]) / 2), float(T3.loc["Pooled", "U_B_k2"])]
OUT["models_lomo_gt_U"] = PM.index[PM.lomo_max_shift > PM.U_B].tolist()
# --- 3. reference timing: reference measured before installation?
a2 = m.copy(); inst = a2.iv_date - pd.to_timedelta(a2.days, unit="D")
gap = (a2.ref_date - inst).dt.days
OUT["ref_after_install_n"] = int((gap > 0).sum()); OUT["ref_after_install_max_days"] = float(gap.max()); OUT["n_meas_all"] = len(a2)
ee = e.copy(); inst_e = ee.iv_date - pd.to_timedelta(ee.days, unit="D"); gap_e = (ee.ref_date - inst_e).dt.days
OUT["ref_after_install_analysis"] = [int((gap_e > 0).sum()), float(gap_e[gap_e > 0].median()) if (gap_e > 0).any() else 0.0, int(ee.loc[gap_e > 0, "Mod_ID"].nunique())]
# --- 4. EL sensitivity
# EL visit pairs with changes in acquisition settings between first and last visit
ELall = pd.read_csv(os.path.join(BASE, "el_out", "el_visit_pairs.csv"))
_first = a.sort_values("days").groupby("Mod_ID").head(1).set_index("Mod_ID")
_last = a.sort_values("days").groupby("Mod_ID").tail(1).set_index("Mod_ID")
for col, src_col in (("d_expL", "Low_Sensor_Exposure_Time_(s)"), ("d_expH", "High_Sensor_Exposure_Time_(s)"),
                     ("d_wd", "Working_Distance_(m)")):
    if col not in ELall:
        ELall[col] = ELall.Mod_ID.map(_last[src_col] - _first[src_col])
P11 = ELall.copy()
ok = {"6x10", "6x12", "4x8", "5x8", "4x10", "5x10", "5x9", "4x9", "5x11", "4x11"}
P11 = P11[~P11.model_id.isin({"22-3", "22-4"}) & (P11.grid1 == P11.grid2) & P11.grid1.isin(ok)]
un = (P11.d_expL.fillna(0) == 0) & (P11.d_expH.fillna(0) == 0) & (P11.d_wd.fillna(0) == 0)
U_ = P11[un]
st = stats.binomtest(int((U_.d_rs_std_med > 0).sum()), int((U_.d_rs_std_med != 0).sum()))
OUT["EL_unchanged"] = dict(n=int(un.sum()), median=float(U_.d_rs_std_med.median()), n_pos=int((U_.d_rs_std_med > 0).sum()),
    sign_p=float(st.pvalue), rho=float(stats.spearmanr(U_.dRs_abs, U_.d_rs_std_med)[0]), rho_p=float(stats.spearmanr(U_.dRs_abs, U_.d_rs_std_med)[1]),
    sigma=float(1.4826 * np.median(np.abs(U_.d_rs_std_med - U_.d_rs_std_med.median()))))
OUT["EL_models"] = [int(P11.model_id.nunique()), P11.model_id.value_counts().max(), P11.model_id.value_counts().idxmax()]
OUT["align_rho_q"] = ELall.align_rho.quantile([0, 0.05, 0.5]).round(3).tolist()
json.dump(OUT, open(os.path.join(SENS, "sens.json"), "w"), indent=1, default=str)
print(json.dumps(OUT, indent=1, default=str)); print(PM.round(3))


# ================= Part 2: imputation, mixed-c models, bootstrap of free intercept =================
c_nom = np.where(np.isnan(cal), 1.0, cal)
yA = (P / P0 - 1) * 100; yB = (P / c_nom ** BETA / P0 - 1) * 100
def pooled(y, k): return np.sum(y[k] * t[k]) / np.sum(t[k] ** 2)
cc = ~np.isnan(cal)
print("complete case: A", round(pooled(yA, cc),3), "B", round(pooled(yB, cc),3), "shift", round(pooled(yB,cc)-pooled(yA,cc),3))
mis = ~cc; print("missing-c measurements", mis.sum(), "models", e.loc[mis,'model_id'].value_counts().to_dict(), "years", pd.Series(years[mis]).value_counts().to_dict())
# per-model: models with both c=1 and c!=1
for mm in models:
    k=(e.model_id==mm).values; s=np.isclose(c_nom,1)&cc&k; d=(~np.isclose(c_nom,1))&cc&k
    if s.sum()>=3 and d.sum()>=3:
        print(mm, 'n same',s.sum(),'n changed',d.sum(), 'A same',round(pooled(yA,s),2),'A changed',round(pooled(yA,d),2),'B changed',round(pooled(yB,d),2), 't same', round(t[s].mean(),2), 't changed', round(t[d].mean(),2))
# intercept model with module bootstrap
rng=np.random.default_rng(1)
mods=e.Mod_ID.values; um=np.unique(mods); groups={u:np.where(mods==u)[0] for u in um}
bs=[]
for _ in range(2000):
    pick=np.concatenate([groups[u] for u in rng.choice(um,len(um))])
    X=np.c_[np.ones(len(pick)),t[pick]]; a,b=np.linalg.lstsq(X,yB[pick],rcond=None)[0]
    bs.append((a, b, np.sum(yB[pick] * t[pick]) / np.sum(t[pick] ** 2)))
bs=np.array(bs)
X=np.c_[np.ones(len(t)),t]; a,b=np.linalg.lstsq(X,yB,rcond=None)[0]
print("intercept",round(a,3),np.percentile(bs[:,0],[2.5,97.5]).round(3),"slope",round(b,3),np.percentile(bs[:,1],[2.5,97.5]).round(3),"origin",np.percentile(bs[:,2],[2.5,97.5]).round(3))
# early measurements: y at t<0.5
k=t<0.5; print("t<0.5: n",k.sum(),"median y_B",round(np.median(yB[k]),2), "models", e.loc[k,'model_id'].nunique())
k=(t>0.05)&(t<0.5); print("0.05<t<0.5 n",k.sum(),"median",round(np.median(yB[k]),2))
# reference age: years between reference and measurement campaigns vs t
age=((e.iv_date-e.ref_date).dt.days/365.25).values; print("ref-to-meas years minus exposure: median",round(np.median(age-t),2),"max",round(np.max(age-t),2))
