# %% [markdown]
# # PV-IV-EL measurement paper: all figures and tables (Figs 2-13, Tables 1-7)
# Usage: PV_BASE=/path/to/data python src/02_figures_tables.py   (PV_NMC sets the Monte Carlo size, default 4000)
# Recomputes everything from the files in the Drive folder:
# `AnonDB.csv`, `IV.zip`, `RefIV.zip`, `EL.zip` (sample images) and, if present, the EL pipeline outputs
# in `el_out/` (`el_visit_pairs.csv`, `delta_maps/*.npy`).
#
# Output: `paper_out/figures/*.png` (600 dpi) + `*.pdf` (vector), `paper_out/tables/*.csv|.tex` and
# `paper_out/tables/all_tables.xlsx`.

# %% Setup --------------------------------------------------------------------------------------
import os, io, re, glob, zipfile, warnings
import numpy as np, pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy import stats
warnings.filterwarnings("ignore")

# Data folder: PV_BASE environment variable; in Colab, PV_BASE may point to a Drive folder, otherwise
# the first Drive folder matching PV_DRIVE_GLOB is used.
try:
    from google.colab import drive  # noqa
    IN_COLAB = True
except ImportError:
    IN_COLAB = False
if "PV_BASE" in os.environ:
    BASE = os.environ["PV_BASE"]
elif IN_COLAB:
    drive.mount("/content/drive")
    BASE = next(p for p in glob.glob(os.environ.get("PV_DRIVE_GLOB", "/content/drive/MyDrive/Research/Solar*"))
                if os.path.isdir(p))
else:
    BASE = "data"

if IN_COLAB:
    os.system("pip -q install pvlib statsmodels openpyxl")
import pvlib
import statsmodels.formula.api as smf
from PIL import Image

EL_ZIP = "/content/EL.zip" if os.path.exists("/content/EL.zip") else os.path.join(BASE, "EL.zip")
EL_OUT = os.path.join(BASE, "el_out")
OUT = os.path.join(BASE, "paper_out")
FIG, TAB = os.path.join(OUT, "figures"), os.path.join(OUT, "tables")
os.makedirs(FIG, exist_ok=True); os.makedirs(TAB, exist_ok=True)
N_MC = int(os.environ.get("PV_NMC", 4000))
RNG = np.random.default_rng(20261012)
EXCLUDE = {"32-2", "38-4"}         # reference-IV anomalies (power gain + Rs drop vs reference)
print("BASE:", BASE, "| EL zip:", EL_ZIP, os.path.exists(EL_ZIP))

# %% Figure style: white background, no grid, minimal text ---------------------------------------
BLUE, ORANGE, AQUA, YELLOW, MAGENTA = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"
GREY, INK, MUTED = "#a9a8a0", "#1f1f1e", "#5f5e58"
MM = 1 / 25.4
W1, W2 = 90 * MM, 190 * MM            # Elsevier single / double column widths
plt.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    "axes.grid": False, "font.family": "DejaVu Sans", "font.size": 7, "axes.labelsize": 7,
    "xtick.labelsize": 6.5, "ytick.labelsize": 6.5, "legend.fontsize": 6.5, "axes.linewidth": 0.6,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
    "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK, "legend.frameon": False, "lines.linewidth": 1.0,
    "pdf.fonttype": 42, "ps.fonttype": 42, "mathtext.default": "it", "mathtext.fontset": "dejavusans"})


def tag(ax, s, x=-0.16, y=1.02):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom", ha="left")


def save(fig, name):
    for ext, kw in (("png", {"dpi": 600}), ("pdf", {})):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"), bbox_inches="tight", pad_inches=0.02, **kw)
    plt.close(fig)
    print("saved", name)


# %% 1. Metadata ---------------------------------------------------------------------------------
a = pd.read_csv(os.path.join(BASE, "AnonDB.csv"))
a["days"] = a.Total_Exposure.str.extract(r"(\d+)").astype(float)
a["yrs"] = a.days / 365.25
a["model_id"] = a.Make.astype(str) + "-" + a.Model.astype(str)
for c in ["IVPath", "RefIVPath", "ELHPath", "ELLPath"]:
    a[c.replace("Path", "f")] = a[c].astype(str).str.split("/").str[-1]
a["Low_Applied_Voltage_(V)"] = pd.to_numeric(a["Low_Applied_Voltage_(V)"].astype(str).str.replace("..", ".", regex=False), errors="coerce")
a["cal_ratio"] = a.RefA / a.RefRefA
a["iv_date"] = pd.to_datetime(a.IV_Date)
a["ref_date"] = pd.to_datetime(a.Ref_IV_Date)
a["wafer"] = a.Cell_Wafer_Type.str.split().str[0]
a = a.drop_duplicates("IVf")
print("rows", len(a), "modules", a.Mod_ID.nunique(), "models", a.model_id.nunique())

# %% 2. I-V parameter extraction (both archives read directly from the zips) --------------------
from pvlib.ivtools.sde import fit_sandia_simple
from scipy.ndimage import uniform_filter1d


def iv_params(d):
    d = d[["V", "I"]].dropna().sort_values("V").reset_index(drop=True)
    V, I = d.V.values, d.I.values
    voc0 = V[I > 0].max()
    m = (V > -0.02 * voc0) & (V < 0.10 * voc0)
    k1, isc = np.polyfit(V[m], I[m], 1)
    m = (I < 0.10 * isc) & (V > 0.7 * voc0)
    k2, voc = np.polyfit(I[m], V[m], 1)
    P = V * I; k = np.argmax(P); m = P > 0.97 * P[k]
    q = np.polyfit(V[m], P[m], 2); vmp = -q[1] / (2 * q[0]); pmp = np.polyval(q, vmp)
    if not (V[m].min() <= vmp <= V[m].max()):
        vmp, pmp = V[k], P[k]
    imp = pmp / vmp
    out = dict(Isc=isc, Voc=voc, Imp=imp, Vmp=vmp, Pmp=pmp, FF=pmp / (isc * voc) * 100,
               Rs0=-k2, Rsh0=-1 / k1 if k1 < 0 else np.nan)
    try:
        s = (V >= 0) & (I >= 0)
        IL, I0, Rs, Rsh, nN = fit_sandia_simple(V[s], I[s], v_oc=voc, i_sc=isc, v_mp_i_mp=(vmp, imp))
        out.update(sd_IL=IL, sd_I0=I0, sd_Rs=Rs, sd_Rsh=Rsh, sd_nNsVth=nN)
    except Exception:
        pass
    return out


CURVES = {}


def read_zip(path, kind):
    rows = []
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if n.lower().endswith(".csv") and "__MACOSX" not in n:
                d = pd.read_csv(z.open(n))
                f = os.path.basename(n)
                CURVES[(kind, f)] = d
                rows.append(dict(kind=kind, file=f, **iv_params(d)))
    return pd.DataFrame(rows)


cache = os.path.join(OUT, "iv_params_paper.csv")
if os.path.exists(cache):
    ivp = pd.read_csv(cache)
    for kind, zp in (("IV", "IV.zip"), ("RefIV", "RefIV.zip")):          # curves still needed for plots
        with zipfile.ZipFile(os.path.join(BASE, zp)) as z:
            for n in z.namelist():
                if n.lower().endswith(".csv") and "__MACOSX" not in n:
                    CURVES[(kind, os.path.basename(n))] = pd.read_csv(z.open(n))
else:
    ivp = pd.concat([read_zip(os.path.join(BASE, "IV.zip"), "IV"), read_zip(os.path.join(BASE, "RefIV.zip"), "RefIV")])
    ivp.to_csv(cache, index=False)
print("curves", len(ivp), ivp.groupby("kind").size().to_dict())

# %% 3. Pair each measurement with its own reference --------------------------------------------
cols = ["Isc", "Voc", "Imp", "Vmp", "Pmp", "FF", "Rs0", "Rsh0", "sd_Rs"]
IVt = ivp[ivp.kind == "IV"].set_index("file")[cols]
REF = ivp[ivp.kind == "RefIV"].set_index("file")[cols].add_suffix("_ref")
m = a.join(IVt, on="IVf").join(REF, on="RefIVf")
m = m.dropna(subset=["Pmp", "Pmp_ref"])
for c in ["Isc", "Voc", "FF", "Pmp"]:
    m[f"d{c}"] = (m[c] / m[f"{c}_ref"] - 1) * 100
    m[f"ln_{c}"] = np.log(m[c] / m[f"{c}_ref"]) * 100
m["dRs"] = m.Rs0 - m.Rs0_ref
m["dRs_pct"] = (m.Rs0 / m.Rs0_ref - 1) * 100
m["cal_state"] = np.where(m.cal_ratio.isna(), "missing", np.where(np.isclose(m.cal_ratio, 1), "same", "changed"))
e = m[(m.days > 0) & ~m.model_id.isin(EXCLUDE)].copy()
keep = e.groupby("model_id").filter(lambda g: (g.yrs.max() >= 1) and (len(g) >= 5)).model_id.unique()
e = e[e.model_id.isin(keep)].reset_index(drop=True)
print("exposed measurements", len(e), "modules", e.Mod_ID.nunique(), "models", e.model_id.nunique())

# %% 4. Monte Carlo uncertainty propagation -----------------------------------------------------
P, P0, T, t = e.Pmp.values, e.Pmp_ref.values, e["Measured_Temperature_(C)"].values, e.yrs.values
cal = e.cal_ratio.values; Imp = e.Imp.values; dRs = e.dRs.values
years = e.iv_date.dt.year.values
cal_pool = {y: g.cal_ratio.dropna().values for y, g in e.groupby(e.iv_date.dt.year)}
all_cal = e.cal_ratio.dropna().values
models = sorted(e.model_id.unique())
idx = {mm: [np.where((e.model_id == mm).values & (e.Mod_ID == mod).values)[0]
            for mod in e.loc[e.model_id == mm, "Mod_ID"].unique()] for mm in models}
ROWS, LABS = np.arange(len(P)), e.model_id.values.astype(object)
BETA, BETA_SD = 0.195, 0.059          # Pmp exponent on calibration ratio (mixed model, Type A)


def boot():
    r, l = [], []
    for mm in models:
        for k in RNG.choice(len(idx[mm]), len(idx[mm])):
            rr = idx[mm][k]; r.append(rr); l.append(np.full(len(rr), mm, dtype=object))
    return np.concatenate(r), np.concatenate(l)


def fit(y, rows, labs):
    tt = t[rows]
    o = {mm: np.sum(y[labs == mm] * tt[labs == mm]) / np.sum(tt[labs == mm] ** 2) for mm in models}
    o["Pooled"] = np.sum(y * tt) / np.sum(tt ** 2)
    return o


def draw(rows, comps, contact=0.0, beta=None):
    n = len(rows); p, p0 = P[rows].copy(), P0[rows].copy()
    if "repeat" in comps:
        p *= 1 + RNG.uniform(-0.005, 0.005, n); p0 *= 1 + RNG.uniform(-0.005, 0.005, n)
    if "extract" in comps:
        p *= 1 + RNG.normal(0, 0.00035, n); p0 *= 1 + RNG.normal(0, 0.00035, n)
    if "temp" in comps:
        g = RNG.normal(-0.0040, 0.0005)
        p /= 1 + g * (T[rows] + RNG.normal(0, 0.5, n) - 25); p0 /= 1 + g * RNG.normal(0, 0.5, n)
    b = beta if beta is not None else (float(np.clip(RNG.normal(BETA, BETA_SD), 0, 1)) if "cal" in comps else BETA)
    c = cal[rows].copy(); mi = np.isnan(c)
    if "cal" in comps and mi.any():
        c[mi] = [RNG.choice(cal_pool[y]) if len(cal_pool.get(y, [])) else RNG.choice(all_cal) for y in years[rows][mi]]
    else:
        c[mi] = 1.0
    p /= c ** b
    p += contact * Imp[rows] ** 2 * dRs[rows]
    return (p / p0 - 1) * 100


ALL = ["repeat", "extract", "temp", "cal"]


def mc(comps, bootstrap=True, contact=0.0, corrected=True, n=N_MC, beta=None):
    out = []
    for _ in range(n):
        rows, labs = boot() if bootstrap else (ROWS, LABS)
        y = draw(rows, comps, contact, beta) if corrected else (P[rows] / P0[rows] - 1) * 100
        out.append(fit(y, rows, labs))
    return pd.DataFrame(out)


print("Monte Carlo ... (N =", N_MC, ")")
RES = {"A": mc([], corrected=False), "B": mc(ALL), "C": mc(ALL, contact=1.0)}
c_nom = np.where(np.isnan(cal), 1.0, cal)
PT = {"A": fit((P / P0 - 1) * 100, ROWS, LABS),
      "B": fit((P / c_nom ** BETA / P0 - 1) * 100, ROWS, LABS),
      "C": fit(((P / c_nom ** BETA + Imp ** 2 * dRs) / P0 - 1) * 100, ROWS, LABS)}
VAR = {"sampling": mc([]).var()}
for comp in ALL:
    VAR[comp] = mc([comp], bootstrap=False).var()
VAR = pd.DataFrame(VAR); VAR["joint"] = RES["B"].var()
SHARE = VAR[["sampling"] + ALL].div(VAR.joint, axis=0) * 100
print("pooled rates:", {k: round(PT[k]["Pooled"], 3) for k in PT})

# %% 5. Tables ----------------------------------------------------------------------------------
meta = e.groupby("model_id").agg(
    wafer=("wafer", "first"), modules=("Mod_ID", "nunique"), measurements=("Mod_ID", "size"),
    nameplate_W=("Nameplate_Pmp_(W)", "first"), max_exposure_yr=("yrs", "max"),
    cal_changed_pct=("cal_state", lambda s: 100 * np.mean(s == "changed")),
    dRs_median_mOhm=("dRs", lambda s: 1000 * s.median()))
T1 = meta.round(2)

T2 = pd.DataFrame({
    "Component": ["Flash-test repeatability", "Temperature correction", "Calibration-current correction",
                  "Parameter extraction", "Test-contact resistance (bound)"],
    "Type": ["B", "B", "A", "A", "B"],
    "Distribution": ["Rectangular, ±0.5 %", "γ ~ N(−0.40, 0.05) %/°C; T ~ N(0, 0.5) °C",
                     "β ~ N(0.195, 0.059)", "N(0, 0.035 %)", "Imp²·ΔRs, fraction 0–1"],
    "u (% of Pmp), median": [0.5 / np.sqrt(3) * np.sqrt(2), np.sqrt(2) * np.hypot(0.40 * 0.5, 0.05 * 0.22),
                             np.median((BETA_SD * np.abs(1 - c_nom) * 100)[c_nom != 1]) if (c_nom != 1).any() else 0,
                             0.035 * np.sqrt(2), np.median(Imp ** 2 * dRs / P * 100)],
    "u (% of Pmp), upper": [np.nan, np.nan, np.max(BETA_SD * np.abs(1 - c_nom) * 100), np.nan,
                            np.percentile(Imp ** 2 * dRs / P * 100, 90)]}).round(3)


def summ(s):
    d = RES[s]
    return pd.DataFrame({f"{s}": pd.Series(PT[s]), f"{s}_lo": d.quantile(0.025), f"{s}_hi": d.quantile(0.975)})


T3 = pd.concat([summ("A"), summ("B"), summ("C")], axis=1)
T3["U_B_k2"] = 2 * RES["B"].std()
T3 = T3.round(3)
T4 = SHARE.round(1)
T5_rows = []
for nm, col in [("Isc", "Isc_(A)"), ("Voc", "Voc_(V)"), ("Pmp", "Pmp_(W)"), ("FF", "FF_(percent)")]:
    r = (m[nm] / m[col] - 1) * 100
    T5_rows.append(dict(parameter=nm, n=int(r.notna().sum()), median_pct=r.median(), p95_abs_pct=r.abs().quantile(0.95),
                        max_abs_pct=r.abs().max()))
T5 = pd.DataFrame(T5_rows).round(4)

el_pairs_path = os.path.join(EL_OUT, "el_visit_pairs.csv")
ELP = pd.read_csv(el_pairs_path) if os.path.exists(el_pairs_path) else None
first = a.sort_values("days").groupby("Mod_ID").head(1).set_index("Mod_ID")
last = a.sort_values("days").groupby("Mod_ID").tail(1).set_index("Mod_ID")
T6 = pd.DataFrame({
    "Item": ["EL image pairs (high + low bias)", "Image bit depth / scaling", "Low-bias exposure changed between visits",
             "High-bias exposure changed, first vs last visit", "Working distance changed, first vs last visit",
             "96-cell modules (8x12 grid)"],
    "Value": [f"{int((a.ELHPath.notna() & a.ELLPath.notna()).sum())}", "8-bit, per-image display scaling",
              f"{int(((last['Low_Sensor_Exposure_Time_(s)'] - first['Low_Sensor_Exposure_Time_(s)']).fillna(0) != 0).sum())} modules",
              f"{int(((last['High_Sensor_Exposure_Time_(s)'] - first['High_Sensor_Exposure_Time_(s)']).fillna(0) != 0).sum())} modules",
              f"{int(((last['Working_Distance_(m)'] - first['Working_Distance_(m)']).fillna(0) != 0).sum())} modules",
              ", ".join(sorted(a.loc[a['Nameplate_Voc_(V)'] > 60, 'model_id'].unique()))]})

with pd.ExcelWriter(os.path.join(TAB, "all_tables.xlsx")) as w:
    for nm, df in [("T1_dataset", T1), ("T2_budget", T2), ("T3_rates", T3), ("T4_shares", T4),
                   ("T5_extraction", T5), ("T6_EL_audit", T6)]:
        df.to_excel(w, sheet_name=nm)
        df.to_csv(os.path.join(TAB, f"{nm}.csv"))
        df.to_latex(os.path.join(TAB, f"{nm}.tex"), float_format="%.3f", escape=True)
print("tables written")

# %% Fig 0  Measurement chain and analysis workflow (schematic) ------------------------------------
from matplotlib.patches import FancyBboxPatch
fig, ax = plt.subplots(figsize=(W2, 48 * MM)); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")
def box(x, y, w, h, txt, c):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=c, ec="none", alpha=0.18))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=6.5, color=INK)
def arrow(x0, y0, x1, y1):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle="-|>", lw=0.7, color=INK, shrinkA=1, shrinkB=1))
top = [("Reference\nmodule", 2), ("Flash\nsimulator", 18), ("Module\nunder test", 34), ("I–V\ncurve", 50), ("Parameter\nextraction", 66), ("Pair with\nreference I–V", 82)]
for txt, x in top:
    box(x, 25, 13, 10, txt, BLUE)
for (_, x0), (_, x1) in zip(top[:-1], top[1:]):
    arrow(x0 + 13.6, 30, x1 - 0.6, 30)
bot = [("Monte Carlo\npropagation", 82), ("$R_\\mathrm{d}$ per model\n(scenarios A, B, C)", 63), ("Variance\nshares", 44)]
for txt, x in bot:
    box(x, 4, 14, 10, txt, AQUA)
box(2, 4, 15, 10, "EL images\n80% / 20% $I_\\mathrm{sc}$", ORANGE)
box(22, 4, 15, 10, "EL metric $s_\\mathrm{r}$,\ndetection limit", ORANGE)
arrow(88.5, 24.4, 88.5, 14.6); arrow(81.4, 9, 77.6, 9); arrow(62.4, 9, 58.6, 9); arrow(17.6, 9, 21.4, 9)
src = [("Calibration\ncurrent", 18), ("Test\ncontact", 34), ("Temperature", 50)]
for txt, x in src:
    ax.text(x + 6.5, 20.5, txt, ha="center", va="center", fontsize=5.8, color=ORANGE, style="italic")
save(fig, "Fig00_workflow")

# %% Fig 1  Dataset structure: measurement timeline per model + exposure distribution -------------
fig, ax = plt.subplots(1, 2, figsize=(W2, 62 * MM), gridspec_kw={"width_ratios": [3, 1.1], "wspace": 0.28})
order = e.groupby("model_id").iv_date.min().sort_values().index[::-1]
ypos = {k: i for i, k in enumerate(order)}
col = {"same": BLUE, "changed": ORANGE, "missing": GREY}
for st in ("same", "changed", "missing"):
    g = e[e.cal_state == st]
    ax[0].scatter(g.iv_date, g.model_id.map(ypos) + RNG.uniform(-0.18, 0.18, len(g)), s=5, c=col[st],
                  lw=0, label={"same": "$c = 1$", "changed": "$c \\neq 1$", "missing": "$c$ not recorded"}[st])
refs = e.drop_duplicates("Mod_ID")
ax[0].scatter(refs.ref_date, refs.model_id.map(ypos), s=9, facecolor="white", edgecolor=INK, lw=0.5, label="Reference I–V", zorder=3)
ax[0].set_yticks(range(len(order)), order)
ax[0].set_ylabel("Module model")
ax[0].legend(loc="upper left", ncol=4, bbox_to_anchor=(0, 1.13), handletextpad=0.2, columnspacing=0.8, markerscale=1.6)
tag(ax[0], "a", x=-0.1)
ax[1].hist(m.loc[m.days > 0, "yrs"], bins=np.arange(0, 5.6, 0.25), color=BLUE, edgecolor="white", lw=0.4)
ax[1].set_xlabel("Exposure (yr)"); ax[1].set_ylabel("Measurements")
tag(ax[1], "b")
save(fig, "Fig01_dataset")

# %% Fig 2  Sample data: EL pair, zoomed cells, I-V curves --------------------------------------
def el_read(zf, name):
    nm = next((n for n in zf.namelist() if os.path.basename(n) == name), None)
    if nm is None:
        return None
    img = np.array(Image.open(io.BytesIO(zf.read(nm)))).astype(np.float32)
    return img.mean(2) if img.ndim == 3 else img


def show(ax, img, crop=None):
    if crop is not None:
        r0, r1, c0, c1 = crop; img = img[r0:r1, c0:c1]
    lo, hi = np.percentile(img, [1, 99.7])
    ax.imshow(img, cmap="gray", vmin=lo, vmax=hi, interpolation="lanczos")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)


def pick_modules():
    """Longest-exposed module with two EL visits, for the most common mono and multi model."""
    two = a.dropna(subset=["ELHPath"]).groupby("Mod_ID").filter(lambda g: len(g) >= 2)
    two = two[~two.model_id.isin(EXCLUDE | {"22-3", "22-4"})]
    out = {}
    for w in ("mono-Si", "multi-Si"):
        g = two[two.wafer == w]
        if len(g):
            top = g.model_id.value_counts().index[0]
            out[w] = g[g.model_id == top].sort_values("days").Mod_ID.iloc[-1]
    return out


if os.path.exists(EL_ZIP):
    zf = zipfile.ZipFile(EL_ZIP)
    pm = pick_modules()
    mono = a[a.Mod_ID == pm.get("mono-Si", a.Mod_ID.iloc[0])].sort_values("days")
    multi = a[a.Mod_ID == pm.get("multi-Si", a.Mod_ID.iloc[0])].sort_values("days")
    H = el_read(zf, mono.ELHf.iloc[-1]); L = el_read(zf, mono.ELLf.iloc[-1])
    Hm = el_read(zf, multi.ELHf.iloc[-1])
    if H is not None and L is not None:
        fig = plt.figure(figsize=(W2, 78 * MM))
        gs = fig.add_gridspec(2, 5, width_ratios=[1.6, 1.6, 0.8, 0.22, 1.3], hspace=0.06, wspace=0.08)
        a1, a2 = fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1])
        show(a1, H); show(a2, L)
        h, w = H.shape
        crop = (int(h * 0.35), int(h * 0.35) + int(h * 0.22), int(w * 0.40), int(w * 0.40) + int(h * 0.22))
        for ax_ in (a1, a2):
            ax_.add_patch(Rectangle((crop[2], crop[0]), crop[3] - crop[2], crop[1] - crop[0], fill=False, ec=YELLOW, lw=0.8))
        a3, a4 = fig.add_subplot(gs[0, 2]), fig.add_subplot(gs[1, 2])
        show(a3, H, crop); show(a4, L, crop)
        a1.set_title("80% $I_\\mathrm{sc}$", fontsize=7, pad=2); a2.set_title("20% $I_\\mathrm{sc}$", fontsize=7, pad=2)
        tag(a1, "a", x=0, y=1.0); tag(a2, "b", x=0, y=1.0); tag(a3, "c", x=0, y=1.0); tag(a4, "d", x=0, y=1.0)
        a5 = fig.add_subplot(gs[1, 0])
        if Hm is not None:
            show(a5, Hm); tag(a5, "e", x=0, y=1.0)
        # single-visit Rs-sensitive map: ln of normalised high-bias over normalised low-bias image
        a6 = fig.add_subplot(gs[1, 1])
        if H.shape == L.shape:
            msk = (H > np.percentile(H, 20)) & (L > np.percentile(L, 20))
            Hn, Ln = H / np.median(H[msk]), L / np.median(L[msk])
            rmap = np.where(msk, np.log(np.clip(Hn, 1e-3, None) / np.clip(Ln, 1e-3, None)), np.nan)
            lim = np.nanpercentile(np.abs(rmap), 98)
            a6.imshow(rmap, cmap="RdBu_r", vmin=-lim, vmax=lim, interpolation="lanczos")
            a6.set_xticks([]); a6.set_yticks([])
            for s_ in a6.spines.values():
                s_.set_visible(False)
            tag(a6, "f", x=0, y=1.0)
        else:
            a6.axis("off")
        a7 = fig.add_subplot(gs[:, 4])
        ivr = CURVES.get(("RefIV", mono.RefIVf.iloc[-1])); ivl = CURVES.get(("IV", mono.IVf.iloc[-1]))
        for d_, c_, lab in ((ivr, GREY, "Reference"), (ivl, BLUE, f"{mono.yrs.iloc[-1]:.1f} yr")):
            if d_ is not None:
                d_ = d_.sort_values("V"); d_ = d_[(d_.V >= 0) & (d_.I >= 0)]
                a7.plot(d_.V, d_.I, color=c_, lw=1.0, label=lab)
                pp = iv_params(d_); a7.plot(pp["Vmp"], pp["Imp"], "o", ms=3, color=c_)
        a7.set_xlabel("Voltage (V)"); a7.set_ylabel("Current (A)"); a7.set_xlim(left=0); a7.set_ylim(bottom=0)
        a7.legend(loc="lower left"); tag(a7, "g", x=-0.22)
        save(fig, "Fig02_sample_data")
else:
    print("EL.zip not found - Fig. 2 skipped")

# %% Fig 3  Extraction validation ----------------------------------------------------------------
fig, ax = plt.subplots(1, 3, figsize=(W2, 55 * MM), gridspec_kw={"wspace": 0.42})
ax[0].scatter(m["Pmp_(W)"], m.Pmp, s=4, color=BLUE, lw=0)
lo, hi = np.nanmin(m.Pmp) * 0.98, np.nanmax(m.Pmp) * 1.02
ax[0].plot([lo, hi], [lo, hi], color=INK, lw=0.6); ax[0].set_xlim(lo, hi); ax[0].set_ylim(lo, hi)
ax[0].set_xlabel("Published $P_\\mathrm{mp}$ (W)"); ax[0].set_ylabel("Extracted $P_\\mathrm{mp}$ (W)"); ax[0].set_aspect("equal")
tag(ax[0], "a", x=-0.3)
res = [((m[nm] / m[c] - 1) * 100).dropna() for nm, c in [("Isc", "Isc_(A)"), ("Voc", "Voc_(V)"), ("Pmp", "Pmp_(W)"), ("FF", "FF_(percent)")]]
bp = ax[1].boxplot(res, widths=0.5, showfliers=False, patch_artist=True, medianprops=dict(color=INK, lw=0.8),
                   whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
for b_, c_ in zip(bp["boxes"], [BLUE, ORANGE, AQUA, YELLOW]):
    b_.set_facecolor(c_); b_.set_edgecolor("white")
ax[1].axhline(0, color=INK, lw=0.5)
ax[1].set_xticks([1, 2, 3, 4], ["$I_\\mathrm{sc}$", "$V_\\mathrm{oc}$", "$P_\\mathrm{mp}$", "FF"]); ax[1].set_ylabel("Extracted − published (%)")
tag(ax[1], "b", x=-0.3)
ex = m.dropna(subset=["sd_Rs"]).iloc[0]
d_ = CURVES[("IV", ex.IVf)].sort_values("V"); d_ = d_[(d_.V >= 0) & (d_.I >= 0)]
r = ivp[(ivp.kind == "IV") & (ivp.file == ex.IVf)].iloc[0]
vv = np.linspace(0, r.Voc, 200)
ii = pvlib.pvsystem.i_from_v(vv, r.sd_IL, r.sd_I0, r.sd_Rs, r.sd_Rsh, r.sd_nNsVth)
ax[2].plot(d_.V, d_.I, ".", ms=1.2, color=GREY, label="Measured")
ax[2].plot(vv, ii, color=BLUE, lw=1.0, label="Single-diode fit")
ax[2].set_xlabel("Voltage (V)"); ax[2].set_ylabel("Current (A)"); ax[2].set_xlim(0); ax[2].set_ylim(0)
ax[2].legend(loc="lower left", markerscale=4); tag(ax[2], "c", x=-0.3)
save(fig, "Fig03_extraction_validation")

# %% Fig 4  Simulator calibration effect ------------------------------------------------------------
fig, ax = plt.subplots(1, 3, figsize=(W2, 55 * MM), gridspec_kw={"wspace": 0.45})
q = e.dropna(subset=["cal_ratio"])
xx = (q.cal_ratio - 1) * 100
ax[0].scatter(xx + RNG.uniform(-0.12, 0.12, len(q)), q.dIsc, s=4, color=ORANGE, lw=0, alpha=0.8)
fr = smf.mixedlm("dIsc ~ cal + yrs", q.assign(cal=xx), groups=q.Mod_ID).fit()
gx = np.linspace(xx.min(), xx.max(), 20)
ax[0].plot(gx, fr.params.Intercept + fr.params.cal * gx + fr.params.yrs * q.yrs.median(), color=INK, lw=0.9)
ax[0].set_xlabel("$(c-1)$ (%)"); ax[0].set_ylabel("$\\Delta I_\\mathrm{sc}$ (%)"); tag(ax[0], "a", x=-0.3)
for st in ("same", "changed", "missing"):
    g = e[e.cal_state == st]
    ax[1].scatter(g.yrs, g.dPmp, s=4, color=col[st], lw=0, label={"same": "$c = 1$", "changed": "$c \\neq 1$", "missing": "$c$ not recorded"}[st])
ax[1].axhline(0, color=INK, lw=0.5)
ax[1].set_xlabel("Exposure (yr)"); ax[1].set_ylabel("$\\Delta P_\\mathrm{mp}$ (%)"); ax[1].legend(loc="lower left", markerscale=2, handletextpad=0.1)
tag(ax[1], "b", x=-0.3)
grp = [("All", e), ("$c = 1$", e[e.cal_state == "same"])]
xb = np.arange(3)
for i, (lab, g) in enumerate(grp):
    ax[2].bar(xb + (i - 0.5) * 0.38, [g.ln_Isc.mean(), g.ln_Voc.mean(), g.ln_FF.mean()], 0.36,
              color=[ORANGE, BLUE][i], edgecolor="white", lw=0.5, label=lab)
ax[2].axhline(0, color=INK, lw=0.5); ax[2].set_xticks(xb, ["$I_\\mathrm{sc}$", "$V_\\mathrm{oc}$", "FF"])
ax[2].set_ylabel("Mean $\\Delta \\ln X$ (%)"); ax[2].legend(loc="lower right"); tag(ax[2], "c", x=-0.3)
save(fig, "Fig04_calibration_effect")

# %% Fig 5  Per-measurement uncertainty budget ---------------------------------------------------
fig, ax = plt.subplots(figsize=(W1, 55 * MM))
lab = ["Repeat-\nability", "Temper-\nature", "Calibra-\ntion", "Extrac-\ntion", "Test\ncontact"]
v = T2["u (% of Pmp), median"].values; up = T2["u (% of Pmp), upper"].values
cc = [AQUA, YELLOW, ORANGE, GREY, MAGENTA]
ax.bar(range(5), v, 0.6, color=cc, edgecolor="white")
for i in range(5):
    if not np.isnan(up[i]):
        ax.plot([i, i], [v[i], up[i]], color=INK, lw=0.7); ax.plot([i - 0.1, i + 0.1], [up[i]] * 2, color=INK, lw=0.7)
ax.set_xticks(range(5), lab); ax.set_ylabel("$u_i(y)$ (%)")
save(fig, "Fig05_measurement_budget")

# %% Fig 6  Degradation rate per model under three scenarios --------------------------------------
order6 = list(T3.drop("Pooled").sort_values("B").index) + ["Pooled"]
y6 = np.arange(len(order6))[::-1].astype(float); y6[-1] -= 0.8
fig, ax = plt.subplots(figsize=(W1 * 1.25, 100 * MM))
for k, y in zip(order6, y6):
    r = T3.loc[k]
    ax.hlines(y + 0.17, r.A_lo, r.A_hi, color=ORANGE, lw=1.1); ax.plot(r.A, y + 0.17, "o", ms=3.2, mfc="white", mec=ORANGE, mew=0.9)
    ax.hlines(y - 0.17, r.B_lo, r.B_hi, color=BLUE, lw=1.1); ax.plot(r.B, y - 0.17, "o", ms=3.2, color=BLUE)
    ax.plot([r.B, r.C], [y - 0.17] * 2, color=AQUA, lw=0.6, ls=(0, (2, 1.5)))
    ax.plot(r.C, y - 0.17, "D", ms=3, mfc="white", mec=AQUA, mew=0.9)
ax.axvline(0, color=INK, lw=0.5)
ax.set_yticks(y6, order6); ax.get_yticklabels()[-1].set_fontweight("bold")
ax.set_xlabel("$R_\\mathrm{d}$ (%/yr)")
ax.plot([], [], "o", ms=3.2, mfc="white", mec=ORANGE, color=ORANGE, label="A, as released")
ax.plot([], [], "o", ms=3.2, color=BLUE, label="B, corrected")
ax.plot([], [], "D", ms=3, mfc="white", mec=AQUA, label="C, contact bound")
ax.legend(loc="upper right", bbox_to_anchor=(1.02, 1.0), frameon=True, facecolor="white", edgecolor="none", framealpha=1)
save(fig, "Fig06_rates_scenarios")

# %% Fig 7  Variance shares ----------------------------------------------------------------------
S = SHARE.loc[order6].clip(lower=0)
S = S.div(S.sum(axis=1), axis=0) * 100
fig, ax = plt.subplots(figsize=(W1 * 1.25, 100 * MM))
comp = [("sampling", "Module sampling", BLUE), ("cal", "Calibration", ORANGE), ("repeat", "Repeatability", AQUA),
        ("temp", "Temperature", YELLOW), ("extract", "Extraction", GREY)]
for k, y in zip(order6, y6):
    left = 0
    for c_, l_, col_ in comp:
        ax.barh(y, S.loc[k, c_], left=left, color=col_, height=0.66, edgecolor="white", lw=0.6, label=l_ if k == order6[0] else None)
        left += S.loc[k, c_]
ax.set_yticks(y6, order6); ax.get_yticklabels()[-1].set_fontweight("bold")
ax.set_xlim(0, 100); ax.set_xlabel("Share of variance of $R_\\mathrm{d}$ (%)")
ax.legend(loc="upper center", bbox_to_anchor=(0.45, -0.1), ncol=3, handlelength=1.0)
save(fig, "Fig07_variance_shares")

# %% Fig 8  Contact resistance: Rs-FF link, correction validation, per-model shift ----------------
fig, ax = plt.subplots(1, 3, figsize=(W2, 55 * MM), gridspec_kw={"wspace": 0.45})
ax[0].scatter(e.dRs * 1000, e.dFF, s=4, color=BLUE, lw=0)
k8 = np.polyfit(e.dRs * 1000, e.dFF, 1); gx = np.linspace((e.dRs * 1000).min(), (e.dRs * 1000).max(), 20)
ax[0].plot(gx, np.polyval(k8, gx), color=INK, lw=0.8)
ax[0].text(0.97, 0.95, ("$r$ = " + f"{np.corrcoef(e.dRs, e.dFF)[0, 1]:.2f}".replace("-", "\u2212")), transform=ax[0].transAxes, ha="right", va="top")
ax[0].set_xlabel("$\\Delta R_\\mathrm{s}$ (m$\\Omega$)"); ax[0].set_ylabel("$\\Delta$FF (percentage points)"); tag(ax[0], "a", x=-0.3)
sub = ivp[(ivp.kind == "IV")].dropna(subset=["sd_Rs"]).sample(60, random_state=1)
ex_, ap_ = [], []
for _, rr in sub.iterrows():
    b0 = pvlib.pvsystem.singlediode(rr.sd_IL, rr.sd_I0, rr.sd_Rs, rr.sd_Rsh, rr.sd_nNsVth)
    for dR in (0.005, 0.01, 0.02, 0.03):
        b1 = pvlib.pvsystem.singlediode(rr.sd_IL, rr.sd_I0, rr.sd_Rs + dR, rr.sd_Rsh, rr.sd_nNsVth)
        ex_.append(b0["p_mp"] - b1["p_mp"]); ap_.append(b0["i_mp"] ** 2 * dR)
ex_, ap_ = np.array(ex_, float), np.array(ap_, float)
ax[1].scatter(ex_, ap_, s=4, color=MAGENTA, lw=0)
mx = max(ex_.max(), ap_.max()) * 1.05
ax[1].plot([0, mx], [0, mx], color=INK, lw=0.6); ax[1].set_xlim(0, mx); ax[1].set_ylim(0, mx); ax[1].set_aspect("equal")
ax[1].set_xlabel("$\\Delta P_\\mathrm{mp}$, single-diode model (W)"); ax[1].set_ylabel("$I_\\mathrm{mp}^2\\,\\Delta R_\\mathrm{s}$ (W)"); tag(ax[1], "b", x=-0.3)
sh = (T3.C - T3.B).drop("Pooled").sort_values()
ax[2].barh(range(len(sh)), sh.values, color=AQUA, height=0.66, edgecolor="white")
ax[2].set_yticks(range(len(sh)), sh.index, fontsize=5.5); ax[2].axvline(0, color=INK, lw=0.5)
ax[2].set_xlabel("Shift in $R_\\mathrm{d}$, C − B (%/yr)"); tag(ax[2], "c", x=-0.3)
save(fig, "Fig08_contact_resistance")
T7 = pd.DataFrame({"rel_err_pct": (ap_ / ex_ - 1) * 100}).describe().round(3)
T7.to_csv(os.path.join(TAB, "T7_contact_correction_validation.csv"))

# %% Fig 9  Monte Carlo: distributions and convergence ------------------------------------------
fig, ax = plt.subplots(1, 2, figsize=(W2 * 0.75, 55 * MM), gridspec_kw={"wspace": 0.35})
bins = np.linspace(min(RES[k].Pooled.min() for k in "ABC"), max(RES[k].Pooled.max() for k in "ABC"), 70)
for k, c_ in zip("ABC", (ORANGE, BLUE, AQUA)):
    hh, _, _ = ax[0].hist(RES[k].Pooled, bins=bins, color=c_, alpha=0.75, edgecolor="none")
    ax[0].text(RES[k].Pooled.median(), hh.max() * 1.04, k, ha="center", va="bottom", fontsize=7, fontweight="bold", color=c_)
ax[0].set_xlabel("Pooled $R_\\mathrm{d}$ (%/yr)"); ax[0].set_ylabel("Trials"); ax[0].margins(y=0.12); tag(ax[0], "a", x=-0.25)
xb = RES["B"].Pooled.values; nn = np.arange(50, len(xb) + 1)
ax[1].plot(nn, [xb[:i].std(ddof=1) for i in nn], color=BLUE, lw=0.9)
ax[1].axhline(xb.std(ddof=1), color=INK, lw=0.5, ls=(0, (2, 2)))
ax[1].set_xlabel("Monte Carlo trials"); ax[1].set_ylabel("$u(R_\\mathrm{d})$ (%/yr)"); tag(ax[1], "b", x=-0.25)
save(fig, "Fig09_monte_carlo")

# %% Fig 10  Sensitivity of the pooled rate to the two systematic corrections ---------------------
fig, ax = plt.subplots(1, 2, figsize=(W2 * 0.75, 55 * MM), gridspec_kw={"wspace": 0.35})
grid = np.linspace(0, 1, 11)
for j, (name, kw) in enumerate((("β", "beta"), ("f", "contact"))):
    mid, lo_, hi_ = [], [], []
    for gv in grid:
        d = mc(ALL, n=max(300, N_MC // 10), **({"beta": gv} if kw == "beta" else {"contact": gv}))
        mid.append(d.Pooled.median()); lo_.append(d.Pooled.quantile(0.025)); hi_.append(d.Pooled.quantile(0.975))
    ax[j].fill_between(grid, lo_, hi_, color=[ORANGE, AQUA][j], alpha=0.25, lw=0)
    ax[j].plot(grid, mid, color=[ORANGE, AQUA][j], lw=1.1)
    ax[j].set_xlabel({"beta": "Calibration exponent $\\beta$", "contact": "Contact fraction $f$"}[kw])
    ax[j].set_ylabel("Pooled $R_\\mathrm{d}$ (%/yr)"); tag(ax[j], "ab"[j], x=-0.25)
ax[0].axvline(BETA, color=INK, lw=0.5, ls=(0, (2, 2)))
save(fig, "Fig10_sensitivity")

# %% Fig 11  EL metric: change against R_s growth, and influence of acquisition ---------------------
if ELP is not None:
    ok_grid = {"6x10", "6x12", "4x8", "5x8", "4x10", "5x10", "5x9", "4x9", "5x11", "4x11"}
    P11 = ELP[~ELP.model_id.isin({"22-3", "22-4"}) & (ELP.grid1 == ELP.grid2) & ELP.grid1.isin(ok_grid)].copy()
    if "d_expL" not in P11:
        P11["d_expL"] = P11.Mod_ID.map(last["Low_Sensor_Exposure_Time_(s)"] - first["Low_Sensor_Exposure_Time_(s)"])
    dsr = P11.d_rs_std_med
    sig = 1.4826 * np.median(np.abs(dsr - dsr.median()))
    YL = 0.12
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(W2 * 0.75, 55 * MM), gridspec_kw={"wspace": 0.45, "width_ratios": [1.5, 1]})
    a1.axhspan(-2 * sig, 2 * sig, color=GREY, alpha=0.18, lw=0)
    inr = dsr.abs() <= YL
    a1.scatter(P11.dRs_abs[inr] * 1000, dsr[inr], s=5, color=BLUE, lw=0)
    out = P11[~inr]
    a1.scatter(out.dRs_abs * 1000, np.sign(out.d_rs_std_med) * YL * 0.97, s=14, marker="^", color=ORANGE, lw=0, clip_on=False)
    if len(out):
        a1.text(0.02, 0.03, f"\u25b2 off scale ({len(out)} modules)", transform=a1.transAxes, fontsize=5.5, color=MUTED, va="bottom")
    a1.set_ylim(-YL, YL); a1.axhline(0, color=INK, lw=0.5)
    rho = stats.spearmanr(P11.dRs_abs, dsr, nan_policy="omit")[0]
    a1.set_title("Spearman $\\rho$ = " + f"{rho:.2f}".replace("-", "\u2212"), loc="right", fontsize=6.5, pad=2)
    a1.set_xlabel("$\\Delta R_\\mathrm{s}$ (m$\\Omega$)"); a1.set_ylabel("$\\Delta s_\\mathrm{r}$"); tag(a1, "a", x=-0.3)
    ch = P11.d_expL.fillna(0) != 0
    a2.axhspan(-2 * sig, 2 * sig, color=GREY, alpha=0.18, lw=0)
    a2.boxplot([dsr[~ch].dropna(), dsr[ch].dropna()], widths=0.5, showfliers=False,
               patch_artist=True, boxprops=dict(facecolor=BLUE, edgecolor="white"), medianprops=dict(color=INK, lw=0.8))
    a2.set_xticks([1, 2], [f"Unchanged\n(n = {(~ch).sum()})", f"Changed\n(n = {ch.sum()})"])
    a2.set_xlabel("Low-bias exposure time"); a2.axhline(0, color=INK, lw=0.5)
    a2.set_ylabel("$\\Delta s_\\mathrm{r}$"); tag(a2, "b", x=-0.4)
    print(f"Fig 11: n = {len(P11)}, sigma_delta = {sig:.4f}, 2 sigma = {2 * sig:.4f}, off-scale = {len(out)}")
    save(fig, "Fig11_EL_results")
else:
    print("el_out/el_visit_pairs.csv not found - Fig. 11 skipped")

# %% Fig 12  Case studies: largest EL changes, first vs last visit ---------------------------------
if ELP is not None and os.path.exists(EL_ZIP):
    zf = zipfile.ZipFile(EL_ZIP)
    cases = P11.nlargest(3, "d_rs_std_med").Mod_ID.tolist() if "P11" in dir() else []
    rows_ = []
    for mod in cases:
        g = a[a.Mod_ID == mod].dropna(subset=["ELHPath"]).sort_values("days")
        i0, i1 = el_read(zf, g.ELHf.iloc[0]), el_read(zf, g.ELHf.iloc[-1])
        if i0 is not None and i1 is not None:
            dp = m.loc[m.IVf == g.IVf.iloc[-1], "dPmp"]
            rows_.append((mod, g, i0, i1, dp.iloc[0] if len(dp) else np.nan))
    if rows_:
        asp = np.mean([r_[2].shape[0] / r_[2].shape[1] for r_ in rows_])
        fig, ax = plt.subplots(len(rows_), 2, figsize=(W2, len(rows_) * (W2 / 2 * asp + 7 * MM)),
                               gridspec_kw={"wspace": 0.03, "hspace": 0.16})
        ax = np.atleast_2d(ax)
        for i, (mod, g, i0, i1, dp) in enumerate(rows_):
            show(ax[i, 0], i0); show(ax[i, 1], i1)
            ax[i, 0].set_title(f"Module {int(mod)} (model {g.model_id.iloc[0]}), {g.yrs.iloc[0]:.1f} yr", fontsize=6.5, pad=2, loc="left")
            ax[i, 1].set_title(f"{g.yrs.iloc[-1]:.1f} yr" + ("" if np.isnan(dp) else ",  $\\Delta P_\\mathrm{mp}$ = " + f"{dp:+.1f}%".replace("-", "\u2212")), fontsize=6.5, pad=2, loc="left")
            tag(ax[i, 0], "abc"[i], x=-0.06, y=1.0)
        save(fig, "Fig12_EL_case_studies")
    else:
        print("case-study images not in EL zip - Fig. 12 skipped")

print("\nDone. Figures:", sorted(os.listdir(FIG)))
print("Tables:", sorted(os.listdir(TAB)))
