"""Optional cosmetic step: re-composes manuscript Figs 3 and 13 (script names Fig02_sample_data and
Fig12_EL_case_studies) from the 600-dpi PNGs written by 02_figures_tables.py, with shorter panel titles.

The pixel crops are tied to the 600-dpi layout of those two figures; if you change that layout, adjust the
crop boxes below. No numbers are computed here.

Usage: python src/05_compose_fig3_fig13.py <PV_BASE>/paper_out/figures <output_dir>
"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
U = sys.argv[1]; OUT = sys.argv[2]
MM = 1 / 25.4; W2 = 190 * MM; INK = "#222222"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7, "mathtext.default": "it", "mathtext.fontset": "dejavusans",
                     "figure.facecolor": "white", "savefig.facecolor": "white", "pdf.fonttype": 42})
def tag(ax, s, x=-0.02, y=1.02):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=8, fontweight="bold", va="bottom", ha="right")
def save(fig, name):
    for ext, kw in (("png", {"dpi": 600}), ("pdf", {})):
        fig.savefig(f"{OUT}/{name}.{ext}", bbox_inches="tight", pad_inches=0.02, **kw)
def show(ax, img):
    ax.imshow(img, interpolation="lanczos"); ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values(): sp.set_visible(False)
def blackbox(a, r0, r1, c0, c1):
    sub = a[r0:r1, c0:c1].mean(2)
    rows = np.where((sub < 40).mean(1) > 0.5)[0]; cols = np.where((sub < 40).mean(0) > 0.5)[0]
    return a[r0 + rows[0]:r0 + rows[-1] + 1, c0 + cols[0]:c0 + cols[-1] + 1]

# ---- Fig 2: panels a-f cropped from the Colab render, panel g kept, new labels
a2 = np.asarray(Image.open(f"{U}/Fig02_sample_data.png").convert("RGB"))
A = a2[200:700, 12:960]; B = a2[200:700, 1012:1960]; C = a2[213:687, 2012:2486]
E_ = a2[930:1430, 12:960]; F = a2[930:1430, 1012:1960].copy(); D = a2[943:1417, 2012:2486]; G = a2[86:1729, 2500:3502]
from scipy import ndimage as nd
dark = A.mean(2) < 25
lab, _ = nd.label(dark)
edge = set(np.unique(np.r_[lab[0], lab[-1], lab[:, 0], lab[:, -1]])) - {0}
bg = np.isin(lab, list(edge))
F[bg] = 255
fig = plt.figure(figsize=(W2, 80 * MM))
gs = fig.add_gridspec(2, 4, width_ratios=[1, 1, 0.5, 1.05], wspace=0.06, hspace=0.18)
panels = [(A, 0, 0, "a", "80% $I_\\mathrm{sc}$"), (B, 0, 1, "b", "20% $I_\\mathrm{sc}$"), (C, 0, 2, "c", "Detail of (a)"),
          (E_, 1, 0, "e", "Multi-Si, 80% $I_\\mathrm{sc}$"), (F, 1, 1, "f", "$r(x,y)$ of (a)"), (D, 1, 2, "d", "Detail of (b)")]
for img, r, c, t, ttl in panels:
    ax = fig.add_subplot(gs[r, c]); show(ax, img); ax.set_title(ttl, fontsize=6.5, pad=2); tag(ax, t)
ax = fig.add_subplot(gs[:, 3]); show(ax, G); tag(ax, "g", x=0.02, y=0.98)
save(fig, "Fig02_sample_data")

# ---- Fig 12: image regions only, new titles
a12 = np.asarray(Image.open(f"{U}/Fig12_EL_case_studies.png").convert("RGB"))
boxes = [((32, 982), (115, 1829), (1880, 3594)), ((1121, 2072), (115, 1829), (1880, 3594)), ((2211, 3161), (115, 1829), (1880, 3594))]
info = [("3759", "5-6", 2.5, 3.5, -0.4), ("4548", "12-1", 0.0, 0.9, -1.7), ("3280", "15-2", 3.2, 4.3, -5.3)]
fig, ax = plt.subplots(3, 2, figsize=(W2, 3 * (W2 / 2 * 0.555) + 18 * MM), gridspec_kw={"wspace": 0.03, "hspace": 0.16})
for i, ((r0, r1), cl, cr) in enumerate(boxes):
    L = blackbox(a12, r0, r1, *cl); R = blackbox(a12, r0, r1, *cr)
    show(ax[i, 0], L); show(ax[i, 1], R)
    mod, mdl, t0, t1, dp = info[i]
    ax[i, 0].set_title(f"Module {mod} (model {mdl}), first visit, $t$ = {t0:.1f} yr", fontsize=6.5, pad=2, loc="left")
    ax[i, 1].set_title(f"Last visit, $t$ = {t1:.1f} yr, $\\Delta P_\\mathrm{{mp}}$ = " + f"{dp:.1f}%".replace("-", "−"), fontsize=6.5, pad=2, loc="left")
    tag(ax[i, 0], "abc"[i], x=-0.01, y=1.0)
save(fig, "Fig12_EL_case_studies")
print("ok")
