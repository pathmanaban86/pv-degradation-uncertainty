# Data

The raw data are not redistributed here. Download the PV-IV-EL dataset from the Open Energy Data Initiative
(OEDI), submission 8378: https://data.openei.org/submissions/8378

Place these four files in this folder (or in any folder, and point `PV_BASE` at it):

| File | Content |
| --- | --- |
| `AnonDB.csv` | Metadata: one row per measurement (module, model, dates, exposure, simulator calibration `RefA`/`RefRefA`, EL acquisition settings) |
| `IV.zip` | I–V curves of the field measurements |
| `RefIV.zip` | I–V curves of the reference (pre-installation) measurements |
| `EL.zip` | High- and low-bias EL images (TIFF) |

The scripts write their outputs into this same folder:

- `el_out/` from `01_el_pipeline.py` (EL features, `el_visit_pairs.csv`, QC overlays, change maps)
- `paper_out/figures`, `paper_out/tables` from `02_figures_tables.py`
- `paper_out/sensitivity` from `03_sensitivity.py`
